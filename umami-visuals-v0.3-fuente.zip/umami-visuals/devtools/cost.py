#!/usr/bin/env python3
"""
cost - cuenta instrucciones aritmeticas del codigo que genera Mesa para cada shader.
Es una metrica determinista (sin ruido) para comparar optimizaciones.

  python3 devtools/cost.py            -> tabla para ULTRA / DEFAULT / BONITO
  python3 devtools/cost.py DEFAULT    -> solo un nivel

Cuenta por funcion de Mesa:  vs = shader de vertices, fs = shader de pixeles
(instrucciones vectoriales de 8 carriles: el numero absoluto no es el de Mali,
pero la proporcion entre versiones si se conserva).
"""
import os, re, subprocess, sys, json

HERE = os.path.dirname(os.path.abspath(__file__))
PARTS = ["null", "vanilla", "sky", "sun", "clouds", "opaque", "alpha", "water", "mob"]
ALU = re.compile(r"=\s*(fadd|fsub|fmul|fdiv|frem|fneg|fcmp|select|call\s+.*@llvm\.(fma|fmuladd|sqrt|floor|ceil|fabs|minnum|maxnum|sin|cos|exp2|log2|pow|round|trunc|copysign))\b")
TEX = re.compile(r"call .*@(sample|fetch|size)\b|gather")
CHILD = r'''
import sys, math
sys.path.insert(0, %r)
import preview as P
r = P.Renderer(sys.argv[1])
r.frame(0.5 if sys.argv[2]=="stars" else 0.235, math.radians(180), parts=[sys.argv[2]])
''' % HERE


def count(q, part):
    env = dict(os.environ, MESA_SHADER_CACHE_DISABLE="true", GALLIVM_DEBUG="ir",
               LP_NUM_THREADS="1", UM_VS_ONLY="")
    p = subprocess.run([sys.executable, "-c", CHILD, q, part], capture_output=True, text=True, env=env)
    out = {}
    cur = None
    for line in p.stderr.splitlines():
        if line.startswith("define "):
            m = re.search(r"@(\w+)", line)
            name = m.group(1) if m else ""
            cur = "vs" if "vs_variant" in name else ("fs" if name.startswith("fs_variant") else None)
            if cur:
                out.setdefault(cur, [0, 0])
            continue
        if line.startswith("}"):
            cur = None
            continue
        if cur:
            if ALU.search(line):
                out[cur][0] += 1
            if TEX.search(line):
                out[cur][1] += 1
    return {k: v[0] for k, v in out.items()}


if __name__ == "__main__":
    qs = sys.argv[1:] or ["ULTRA", "DEFAULT", "BONITO"]
    res = {}
    for q in qs:
        res[q] = {part: count(q, part) for part in PARTS}
    print("%-8s" % "", "".join("%-16s" % q for q in qs))
    for part in PARTS[2:]:
        row = []
        for q in qs:
            c = res[q][part]
            row.append("vs %4d  fs %4d " % (c.get("vs", 0), c.get("fs", 0)))
        print("%-8s" % part, "".join(row))
    n = res[qs[0]]["null"]
    print("(shader nulo de referencia: vs %d  fs %d)" % (n.get("vs", 0), n.get("fs", 0)))
    v = res[qs[0]]["vanilla"]
    print("(terreno VANILLA de Minecraft: vs %d  fs %d  + 1 textura extra por pixel)" % (v.get("vs", 0), v.get("fs", 0)))
    json.dump(res, open(os.path.join(HERE, "out", "cost_last.json"), "w"), indent=1)
