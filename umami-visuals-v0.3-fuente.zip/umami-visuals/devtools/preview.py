#!/usr/bin/env python3
"""
preview - renderiza una escena de prueba con los shaders reales de Umami Visuals
(compilados como GLSL ES 3.00 en Mesa) y mide el costo de cada material.

  python3 devtools/preview.py render  [--q DEFAULT]   -> devtools/out/preview_*.png
  python3 devtools/preview.py bench   [--q DEFAULT]   -> tiempos por material

La escena imita lo que dibuja Minecraft: cielo de pantalla completa, sol/luna,
estrellas, nubes, terreno con sombra de arbol, hojas (alpha test) y agua.
"""
import ctypes, math, os, sys, time, random
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glcheck as g

GL = g.GL
W, H = 1232, 540          # proporcion 20.5:9 como el Infinix Note 30
OUTDIR = g.OUT

# ---------------------------------------------------------------- GL helpers
c_float_p = ctypes.POINTER(ctypes.c_float)
for fn, res in [("glGetUniformLocation", ctypes.c_int), ("glGetAttribLocation", ctypes.c_int)]:
    getattr(GL, fn).restype = res
    getattr(GL, fn).argtypes = [ctypes.c_uint, ctypes.c_char_p]
_vp, _u, _i = ctypes.c_void_p, ctypes.c_uint, ctypes.c_int
GL.glBufferData.argtypes = [_u, ctypes.c_ssize_t, _vp, _u]
GL.glTexImage2D.argtypes = [_u, _i, _i, _i, _i, _i, _u, _u, _vp]
GL.glReadPixels.argtypes = [_i, _i, _i, _i, _u, _u, _vp]
GL.glUniform4fv.argtypes = [_i, _i, _vp]
GL.glUniformMatrix4fv.argtypes = [_i, _i, ctypes.c_ubyte, _vp]
GL.glVertexAttribPointer.argtypes = [_u, _i, _u, ctypes.c_ubyte, _i, _vp]


def gen(fn):
    v = ctypes.c_uint(); getattr(GL, fn)(1, ctypes.byref(v)); return v.value


def make_fbo(w, h):
    fbo = gen("glGenFramebuffers"); GL.glBindFramebuffer(0x8D40, fbo)
    col = gen("glGenRenderbuffers"); GL.glBindRenderbuffer(0x8D41, col)
    GL.glRenderbufferStorage(0x8D41, 0x8058, w, h)  # RGBA8
    GL.glFramebufferRenderbuffer(0x8D40, 0x8CE0, 0x8D41, col)
    dep = gen("glGenRenderbuffers"); GL.glBindRenderbuffer(0x8D41, dep)
    GL.glRenderbufferStorage(0x8D41, 0x81A6, w, h)  # DEPTH24
    GL.glFramebufferRenderbuffer(0x8D40, 0x8D00, 0x8D41, dep)
    GL.glViewport(0, 0, w, h)
    return fbo


def make_tex(img, nearest=True):
    a = np.ascontiguousarray(np.asarray(img.convert("RGBA"), dtype=np.uint8))
    t = gen("glGenTextures"); GL.glBindTexture(0x0DE1, t)
    f = 0x2600 if nearest else 0x2601
    GL.glTexParameteri(0x0DE1, 0x2801, f); GL.glTexParameteri(0x0DE1, 0x2800, f)
    GL.glTexParameteri(0x0DE1, 0x2802, 0x812F); GL.glTexParameteri(0x0DE1, 0x2803, 0x812F)
    GL.glTexImage2D(0x0DE1, 0, 0x8058, a.shape[1], a.shape[0], 0, 0x1908, 0x1401, a.ctypes.data)
    return t


class Mesh:
    """attrs: dict name -> (np.float32 array Nxk)."""
    def __init__(self, attrs):
        self.n = len(next(iter(attrs.values())))
        self.bufs = {}
        for k, arr in attrs.items():
            arr = np.ascontiguousarray(arr, dtype=np.float32)
            b = gen("glGenBuffers"); GL.glBindBuffer(0x8892, b)
            GL.glBufferData(0x8892, arr.nbytes, arr.ctypes.data, 0x88E4)
            self.bufs[k] = (b, arr.shape[1])


NULL_VS = """#version 300 es
precision highp float;
in vec3 a_position; in vec2 a_texcoord0;
uniform mat4 u_viewProj; uniform mat4 u_model[32];
out vec2 v_uv;
void main(){ v_uv = a_texcoord0*2.0; gl_Position = u_viewProj*(u_model[0]*vec4(a_position,1.0)); }
"""
NULL_FS = """#version 300 es
precision highp float;
in vec2 v_uv; uniform lowp sampler2D s_MatTexture; out vec4 o;
void main(){ o = texture(s_MatTexture, v_uv); }
"""

# replica del terreno vanilla de Bedrock (para comparar): luz leida de la textura
# de luz POR PIXEL, niebla de color plano.
VAN_VS = """#version 300 es
precision highp float;
in vec3 a_position; in vec2 a_texcoord0; in vec2 a_texcoord1; in vec4 a_color0;
uniform mat4 u_viewProj; uniform mat4 u_model[32];
uniform vec4 FogAndDistanceControl; uniform vec4 FogColor; uniform vec4 ViewPositionAndTime;
out vec2 v_uv; out vec2 v_lm; out vec4 v_color0; out vec4 v_fog;
void main(){
  vec3 wp = (u_model[0]*vec4(a_position,1.0)).xyz;
  v_uv = a_texcoord0*2.0; v_lm = fract(a_texcoord1.y*vec2(256.0,4096.0)); v_color0 = a_color0;
  float d = length(wp - ViewPositionAndTime.xyz)/FogAndDistanceControl.z;
  v_fog = vec4(FogColor.rgb, clamp((d - FogAndDistanceControl.x)/(FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
  gl_Position = u_viewProj*vec4(wp,1.0);
}
"""
VAN_FS = """#version 300 es
precision highp float;
in vec2 v_uv; in vec2 v_lm; in vec4 v_color0; in vec4 v_fog;
uniform lowp sampler2D s_MatTexture; uniform lowp sampler2D s_LightMapTexture; out vec4 o;
void main(){
  vec4 d = texture(s_MatTexture, v_uv);
  if (d.a < 0.1) discard;
  d.rgb *= v_color0.rgb; d.a *= v_color0.a;
  d.rgb *= texture(s_LightMapTexture, v_lm).rgb;
  d.rgb = mix(d.rgb, v_fog.rgb, v_fog.a);
  o = d;
}
"""


class Prog:
    def __init__(self, mat, defs):
        if mat in ("NULL", "VANILLA"):
            vsrc, fsrc = (NULL_VS, NULL_FS) if mat == "NULL" else (VAN_VS, VAN_FS)
            vs, ok1, l1 = g.compile_shader(vsrc, "vertex")
            fs, ok2, l2 = g.compile_shader(fsrc, "fragment")
            self.p, ok, l = g.link(vs, fs)
            assert ok1 and ok2 and ok, (l1, l2, l)
            return
        res, _, p = g.build_variant(mat, defs)
        for k, (ok, log) in res.items():
            if not ok:
                raise RuntimeError("%s %s %s: %s" % (mat, defs, k, log))
        self.p = p

    def use(self, uniforms, textures=()):
        GL.glUseProgram(self.p)
        for name, val in uniforms.items():
            loc = GL.glGetUniformLocation(self.p, name.encode())
            if loc < 0:
                continue
            val = np.ascontiguousarray(val, dtype=np.float32).ravel()
            if val.size == 16:
                GL.glUniformMatrix4fv(loc, 1, 0, val.ctypes.data_as(c_float_p))
            else:
                v = np.zeros(4, np.float32); v[:val.size] = val
                GL.glUniform4fv(loc, 1, v.ctypes.data_as(c_float_p))
        for unit, (name, tex) in enumerate(textures):
            loc = GL.glGetUniformLocation(self.p, name.encode())
            GL.glActiveTexture(0x84C0 + unit); GL.glBindTexture(0x0DE1, tex)
            if loc >= 0:
                GL.glUniform1i(loc, unit)

    def draw(self, mesh):
        used = []
        for name, (b, k) in mesh.bufs.items():
            loc = GL.glGetAttribLocation(self.p, name.encode())
            if loc < 0:
                continue
            GL.glBindBuffer(0x8892, b)
            GL.glEnableVertexAttribArray(loc)
            GL.glVertexAttribPointer(loc, k, 0x1406, 0, 0, None)
            used.append(loc)
        GL.glDrawArrays(0x0004, 0, mesh.n)
        for loc in used:
            GL.glDisableVertexAttribArray(loc)


# ---------------------------------------------------------------- math
def perspective(fovy, aspect, n, f):
    t = 1 / math.tan(math.radians(fovy) / 2)
    m = np.zeros((4, 4), np.float32)
    m[0, 0] = t / aspect; m[1, 1] = t
    m[2, 2] = (f + n) / (n - f); m[2, 3] = 2 * f * n / (n - f); m[3, 2] = -1
    return m


def look_rot(yaw, pitch):
    """camara mirando hacia (yaw, pitch); devuelve matriz de vista (solo rotacion)."""
    fwd = np.array([math.cos(pitch) * math.cos(yaw), math.sin(pitch), math.cos(pitch) * math.sin(yaw)])
    right = np.cross(fwd, [0, 1, 0]); right /= np.linalg.norm(right)
    up = np.cross(right, fwd)
    v = np.eye(4, dtype=np.float32)
    v[0, :3] = right; v[1, :3] = up; v[2, :3] = -fwd
    return v


def gl_mat(m):  # numpy fila-mayor -> columna-mayor de GL
    return np.ascontiguousarray(m.T, dtype=np.float32)


# ---------------------------------------------------------------- texturas
def atlas():
    """Texturas de PRUEBA estilo vanilla (pixel art original, 16px), atlas 4x3:
    0 pasto arriba (gris, se tiñe) 1 tierra 2 piedra 3 hojas (gris, se tiñen) 4 agua
    5 tronco 6 arena 7 antorcha 8 pasto de lado"""
    rnd = random.Random(7)
    im = Image.new("RGBA", (128, 64))   # atlas con margen: ninguna coordenada llega a 1.0
    px = im.load()

    def tile(i, fn):
        ox, oy = (i % 4) * 16, (i // 4) * 16
        for y in range(16):
            for x in range(16):
                c = fn(x, y)
                px[ox + x, oy + y] = tuple(max(0, min(255, int(v))) for v in c)

    def pal(cols, weights):
        return rnd.choices(cols, weights)[0]

    # ruido por bloques de 2px para manchas (como vanilla)
    blob = {(x, y): rnd.random() for x in range(9) for y in range(9)}
    def patch(x, y):
        return blob[(x // 2, y // 2)]

    def grass_top(x, y):
        v = pal([150, 168, 186, 200, 214], [2, 4, 6, 4, 2]) * (0.92 + 0.16 * patch(x, y))
        return (v, v, v, 255)
    def dirt(x, y):
        c = pal([(89, 61, 41), (121, 85, 58), (134, 96, 67), (150, 108, 74), (108, 76, 52)], [2, 5, 6, 3, 3])
        return c + (255,)
    def stone(x, y):
        p = patch(x + 1, y)
        base = 104 if p < 0.22 else (143 if p > 0.85 else 125)
        v = base + rnd.choice([-6, 0, 0, 5])
        return (v, v, v, 255)
    def leaves(x, y):
        if rnd.random() < 0.22: return (0, 0, 0, 0)
        v = pal([110, 140, 165, 190], [3, 5, 4, 2])
        return (v, v, v, 255)
    def water(x, y):
        v = 150 + 30 * math.sin((x + 2 * y) * 0.7) * 0.5 + rnd.uniform(-8, 8)
        return (v * 0.95, v, v * 1.08, 180)
    def log(x, y):
        stripe = (x * 37 % 5 == 0) or (x % 4 == 1 and rnd.random() < 0.6)
        c = (77, 61, 38) if stripe else pal([(104, 83, 51), (124, 100, 60), (95, 75, 46)], [5, 3, 3])
        return c + (255,)
    def sand(x, y):
        c = pal([(219, 207, 163), (206, 193, 148), (227, 217, 177), (196, 182, 136)], [6, 3, 3, 1])
        return c + (255,)
    def torch(x, y):
        if 7 <= x <= 8 and 6 <= y <= 9: return (255, 216, 92, 255) if y < 8 else (255, 166, 40, 255)
        if 7 <= x <= 8 and 10 <= y <= 15: return (122, 92, 54, 255) if x == 7 else (98, 72, 40, 255)
        return (0, 0, 0, 0)
    edge = [rnd.choice([3, 4, 4, 5]) for _ in range(16)]
    def grass_side(x, y):
        if y < edge[x]:
            g = pal([(89, 140, 52), (106, 160, 62), (78, 124, 45)], [4, 3, 2])
            return g + (255,)
        return dirt(x, y)
    for i, fn in enumerate([grass_top, dirt, stone, leaves, water, log, sand, torch, grass_side]):
        tile(i, fn)
    return im


def lightmap(day):
    """lightmap estilo vanilla: x = antorcha, y = cielo. (0,0) = brillo minimo del juego."""
    im = Image.new("RGBA", (16, 16)); px = im.load()
    f = lambda l: l / (3.0 - 2.0 * l)
    for y in range(16):
        for x in range(16):
            sky = f(y / 15.0) * (0.18 + 0.82 * day)
            t = f(x / 15.0)
            c = [max(sky, t * k) for k in (1.0, 0.86, 0.66)]
            px[x, y] = tuple(int(255 * min(1, 0.06 + 0.94 * v)) for v in c) + (255,)
    return im


def moon_tex():
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 0)); px = im.load()
    for y in range(32):
        for x in range(32):
            d = math.hypot(x - 15.5, y - 15.5)
            if d < 10:
                v = int(225 - 30 * ((x * 7 + y * 3) % 5 == 0))
                px[x, y] = (v, v, int(v * 1.02), 255)
    return im


# ---------------------------------------------------------------- escena
FACES = {  # normal: (4 esquinas, sombreado vanilla)
    "top": ([(0, 1, 0), (1, 1, 0), (1, 1, 1), (0, 1, 1)], 1.0),
    "bot": ([(0, 0, 1), (1, 0, 1), (1, 0, 0), (0, 0, 0)], 0.5),
    "n": ([(1, 0, 0), (0, 0, 0), (0, 1, 0), (1, 1, 0)], 0.8),
    "s": ([(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)], 0.8),
    "w": ([(0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)], 0.6),
    "e": ([(1, 0, 1), (1, 0, 0), (1, 1, 0), (1, 1, 1)], 0.6),
}


class Builder:
    def __init__(self):
        self.d = {k: [] for k in ("a_position", "a_color0", "a_texcoord0", "a_texcoord1")}

    def quad(self, corners, color, tile, bl, sl):
        tx, ty = (tile % 4) * 0.125, (tile // 4) * 0.25
        uvs = [(0, 1), (1, 1), (1, 0), (0, 0)]
        lm = (bl * 16 + sl) / 65535.0
        for i in (0, 1, 2, 0, 2, 3):
            self.d["a_position"].append(corners[i])
            self.d["a_color0"].append(color)
            u, v = uvs[i]
            # el shader hace uv0 = 2*a_texcoord0 -> pasamos la mitad
            self.d["a_texcoord0"].append(((tx + u * 0.125) / 2.0, (ty + v * 0.25) / 2.0))
            self.d["a_texcoord1"].append((0.0, lm))

    def cube(self, x, y, z, tile, faces, tint=(1, 1, 1), bl=0, sl=15, alpha=1.0, top_tile=None, side_tile=None):
        for f in faces:
            corners, shade = FACES[f]
            c = [(x + a, y + b, z + cc) for a, b, cc in corners]
            t = tile
            if f == "top" and top_tile is not None: t = top_tile
            if f not in ("top", "bot") and side_tile is not None: t = side_tile
            tn = tint if (f == "top" or t in (0, 3)) else (1, 1, 1)
            self.quad(c, (shade * tn[0], shade * tn[1], shade * tn[2], alpha), t, bl, sl)

    def mesh(self):
        return Mesh({k: np.array(v, np.float32) for k, v in self.d.items()})


def build_scene():
    opaque, alpha, water = Builder(), Builder(), Builder()
    grass_tint = (0.57, 0.74, 0.35)   # tinte vanilla de planicies
    leaf_tint = (0.47, 0.67, 0.18)    # tinte vanilla de roble
    size = 56
    def height(x, z):
        return int(3 + 2.2 * math.sin(x * 0.21) + 1.8 * math.cos(z * 0.17) + 1.2 * math.sin((x + z) * 0.09))
    hm = {(x, z): height(x, z) for x in range(-size, size) for z in range(-size, size)}
    tree = (-8, -5)
    leaves = set()
    th = hm[tree] + 1
    for dx in range(-2, 3):
        for dz in range(-2, 3):
            for dy in (3, 4):
                leaves.add((tree[0] + dx, th + dy, tree[1] + dz))
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            leaves.add((tree[0] + dx, th + 5, tree[1] + dz))
    def shadowed(x, y, z):
        return any((x, yy, z) in leaves for yy in range(y + 1, y + 9))
    for (x, z), h in hm.items():
        if -26 <= x <= -15 and -6 <= z <= 6:       # lago
            h = min(h, 1); hm[(x, z)] = h
        sl = 11 if shadowed(x, h, z) else 15
        bl = 0
        dtorch = math.hypot(x + 5, z - 5)
        if dtorch < 6: bl = max(0, int(14 - 2.2 * dtorch))
        faces = ["top"]
        for f, (dx, dz) in (("n", (0, -1)), ("s", (0, 1)), ("w", (-1, 0)), ("e", (1, 0))):
            if hm.get((x + dx, z + dz), -9) < h:
                faces.append(f)
        sand = -27 <= x <= -14 and -7 <= z <= 7
        if sand:
            opaque.cube(x, h, z, 6, faces, bl=bl, sl=sl)
        else:
            opaque.cube(x, h, z, 1, faces, tint=grass_tint, bl=bl, sl=sl, top_tile=0, side_tile=8)
        for yy in range(hm.get((x, z), h) - 3, h):  # paredes de piedra visibles
            sf = [f for f, (dx, dz) in (("n", (0, -1)), ("s", (0, 1)), ("w", (-1, 0)), ("e", (1, 0)))
                  if hm.get((x + dx, z + dz), -9) <= yy]
            if sf: opaque.cube(x, yy, z, 2, sf, bl=bl, sl=sl)
        if -26 <= x <= -15 and -6 <= z <= 6:
            water.quad([(x, 1.875 + 1, z), (x + 1, 1.875 + 1, z), (x + 1, 1.875 + 1, z + 1), (x, 1.875 + 1, z + 1)],
                       (0.25, 0.45, 0.85, 0.65), 4, 0, 15)
    for y in range(th, th + 4):
        opaque.cube(tree[0], y, tree[1], 5, ["n", "s", "w", "e"], sl=14)
    for (x, y, z) in leaves:
        alpha.cube(x, y, z, 3, list(FACES), tint=leaf_tint, sl=15)
    # antorcha
    tx, tz = -5, 5
    ty = hm[(tx, tz)] + 1
    alpha.quad([(tx, ty, tz + .5), (tx + 1, ty, tz + .5), (tx + 1, ty + 1, tz + .5), (tx, ty + 1, tz + .5)], (1, 1, 1, 1), 7, 14, 15)
    alpha.quad([(tx + .5, ty, tz), (tx + .5, ty, tz + 1), (tx + .5, ty + 1, tz + 1), (tx + .5, ty + 1, tz)], (1, 1, 1, 1), 7, 14, 15)
    return opaque.mesh(), alpha.mesh(), water.mesh()


def mob_tex():
    """textura generica de figura de prueba (no es ningun mob real): cabeza clara, cuerpo azul."""
    im = Image.new("RGBA", (16, 16)); px = im.load()
    rnd = random.Random(5)
    for y in range(16):
        for x in range(16):
            if y < 6: c = (214, 170, 130)
            elif y < 12: c = (60, 110, 170)
            else: c = (70, 60, 50)
            k = rnd.uniform(0.9, 1.05)
            px[x, y] = tuple(int(v * k) for v in c) + (255,)
    return im


def build_mob(base):
    """figura de 2 cajas (cuerpo + cabeza) con normales, como las que dibuja el juego."""
    d = {k: [] for k in ("a_position", "a_color0", "a_texcoord0", "a_normal", "a_indices")}
    normals = {"top": (0, 1, 0), "bot": (0, -1, 0), "n": (0, 0, -1), "s": (0, 0, 1), "w": (-1, 0, 0), "e": (1, 0, 0)}
    def box(x0, y0, z0, sx, sy, sz, v0, v1):
        for f, (corners, _) in FACES.items():
            c = [(base[0] + x0 + a * sx, base[1] + y0 + b * sy, base[2] + z0 + cc * sz) for a, b, cc in corners]
            uvs = [(0, v1), (1, v1), (1, v0), (0, v0)]
            for i in (0, 1, 2, 0, 2, 3):
                d["a_position"].append(c[i]); d["a_color0"].append((1, 1, 1, 1))
                d["a_texcoord0"].append(uvs[i]); d["a_normal"].append(normals[f] + (0,)); d["a_indices"].append((0,))
    box(-0.3, 0.0, -0.2, 0.6, 1.3, 0.4, 6 / 16, 1.0)
    box(-0.25, 1.3, -0.25, 0.5, 0.5, 0.5, 0.0, 6 / 16)
    return Mesh({k: np.array(v, np.float32) for k, v in d.items()})


def build_clouds():
    b = Builder()
    rnd = random.Random(3)
    for i in range(90):
        x, z = rnd.uniform(-260, 260), rnd.uniform(-260, 260)
        w, d = rnd.uniform(16, 46), rnd.uniform(12, 30)
        for f, (corners, shade) in FACES.items():
            c = [(x + a * w, 0 + bb * 1.0, z + cc * d) for a, bb, cc in corners]
            b.quad(c, (shade, shade, shade, 1.0), 0, 0, 15)
    return b.mesh()


def build_stars():
    b = Builder(); rnd = random.Random(11)
    for i in range(900):
        th, ph = rnd.uniform(0, 2 * math.pi), math.acos(rnd.uniform(-0.2, 1))
        p = np.array([math.sin(ph) * math.cos(th), math.cos(ph), math.sin(ph) * math.sin(th)]) * 100
        s = rnd.uniform(0.15, 0.35)
        t1 = np.cross(p, [0, 1, 0.01]); t1 = t1 / np.linalg.norm(t1) * s
        t2 = np.cross(p, t1); t2 = t2 / np.linalg.norm(t2) * s
        c = [tuple(p - t1 - t2), tuple(p + t1 - t2), tuple(p + t1 + t2), tuple(p - t1 + t2)]
        v = rnd.uniform(0.5, 1.0)
        b.quad(c, (v, v, v, 1), 0, 0, 15)
    return b.mesh()


def fullscreen_quad():
    # el shader del cielo usa a_position.xzy, con x,z en [-0.5,0.5]
    p = [(-.5, 0, -.5), (.5, 0, -.5), (.5, 0, .5), (-.5, 0, -.5), (.5, 0, .5), (-.5, 0, .5)]
    return Mesh({"a_position": np.array(p, np.float32), "a_color0": np.ones((6, 4), np.float32)})


def sunmoon_quad():
    p = [(-1, 0, -1), (1, 0, -1), (1, 0, 1), (-1, 0, -1), (1, 0, 1), (-1, 0, 1)]
    uv = [(0, 0), (1, 0), (1, 1), (0, 0), (1, 1), (0, 1)]
    return Mesh({"a_position": np.array(p, np.float32), "a_texcoord0": np.array(uv, np.float32)})


# ---------------------------------------------------------------- render
class Renderer:
    def __init__(self, q):
        g.init_gl()
        self.fbo = make_fbo(W, H)
        self.q = q
        P = lambda m, d=(): Prog(m, [q] + list(d))
        self.p = {"sky": P("Sky"), "sun": P("SunMoon"), "stars": P("Stars"), "clouds": P("Clouds"),
                  "opaque": P("RenderChunk", ["OPAQUE"]), "alpha": P("RenderChunk", ["ALPHA_TEST"]),
                  "water": P("RenderChunk", ["TRANSPARENT"]),
                  "null": Prog("NULL", []), "vanilla": Prog("VANILLA", []),
                  }
        if os.path.isdir(os.path.join(g.SRC, "materials", "Actor")):
            self.p["mob"] = P("Actor", ["OPAQUE"])
        self.mobtex = make_tex(mob_tex())
        self.mob = build_mob((-4.5, 3.0, 2.5))
        self.tex = make_tex(atlas())
        self.moon = make_tex(moon_tex(), nearest=False)
        self.lmap = make_tex(lightmap(1.0), nearest=False)
        self.scene = build_scene()
        self.mob_shade = False
        self.clouds = build_clouds()
        self.stars = build_stars()
        self.fsq = fullscreen_quad()
        self.smq = sunmoon_quad()

    def frame(self, tod, yaw, pitch=0.12, rain=0.0, cam=(0.0, 9.0, 0.0), parts=None, fov=70):
        parts = parts or ["sky", "stars", "sun", "clouds", "opaque", "alpha", "mob", "water"]
        rd = 128.0
        fogx = 0.5 + 20.0 / rd
        fog_ctl = (fogx + (0.23 - fogx) * rain, 1.0 - 0.3 * rain, rd, 0)
        proj = perspective(fov, W / H, 0.1, 600)
        view = look_rot(yaw, pitch)
        vp = proj @ view
        common = {"FogAndDistanceControl": fog_ctl, "FogColor": (0.62, 0.74, 0.98, 1),
                  "TimeOfDay": (tod, 0, 0, 0), "ViewPositionAndTime": (0, 0, 0, 37.0),
                  "CameraPosition": (*cam, 0), "RenderChunkFogAlpha": (0, 0, 0, 0),
                  "u_viewProj": gl_mat(vp), "u_invViewProj": gl_mat(np.linalg.inv(vp)),
                  "SunMoonColor": (1, 1, 1, 1.0 - 0.9 * rain), "StarsColor": (1, 1, 1, 1)}
        GL.glBindFramebuffer(0x8D40, self.fbo)
        GL.glViewport(0, 0, *((4, 4) if os.environ.get('UM_VS_ONLY') else (W, H)))
        GL.glClearColor(0, 0, 0, 1)
        GL.glClear(0x4100)
        night = max(0.0, -math.cos(2 * math.pi * tod))
        GL.glDisable(0x0B71); GL.glDepthMask(0)
        if "sky" in parts:
            self.p["sky"].use(common); self.p["sky"].draw(self.fsq)
        GL.glEnable(0x0BE2)
        if "stars" in parts and night > 0.05:
            GL.glBlendFunc(1, 1)
            u = dict(common); u["StarsColor"] = (night, night, night, 1)
            u["u_model[0]"] = gl_mat(np.eye(4))
            self.p["stars"].use(u); self.p["stars"].draw(self.stars)
        if "sun" in parts:
            GL.glBlendFunc(0x0302, 1)   # como el juego: SourceAlpha + One (aditivo)
            st = 2 * math.pi * tod + math.pi / 2
            for is_sun in (True, False):
                m = np.eye(4, dtype=np.float32)
                s = 1 if is_sun else -1
                m[0, 3], m[1, 3] = s * math.cos(st), s * math.sin(st)
                u = dict(common); u["u_model[0]"] = gl_mat(m)
                self.p["sun"].use(u, [("s_SunMoonTexture", self.moon)]); self.p["sun"].draw(self.smq)
        GL.glDisable(0x0BE2)
        # terreno
        GL.glEnable(0x0B71); GL.glDepthMask(1); GL.glDepthFunc(0x0203)
        model = np.eye(4, dtype=np.float32); model[:3, 3] = -np.array(cam)
        u = dict(common); u["u_model[0]"] = gl_mat(model)
        tex = [("s_MatTexture", self.tex), ("s_LightMapTexture", self.lmap)]
        opaque, alpha, water = self.scene
        if "opaque" in parts:
            self.p["opaque"].use(u, tex); self.p["opaque"].draw(opaque)
        if "null" in parts:
            self.p["null"].use(u, tex); self.p["null"].draw(opaque)
        if "vanilla" in parts:
            self.p["vanilla"].use(u, tex); self.p["vanilla"].draw(opaque)
        if "alpha" in parts:
            self.p["alpha"].use(u, tex); self.p["alpha"].draw(alpha)
        if "mob" in parts and "mob" in self.p:
            um = dict(u)
            um["u_model[0]"] = gl_mat(model); um["Bones[0]"] = gl_mat(np.eye(4))
            um["u_view"] = gl_mat(view); um["u_proj"] = gl_mat(proj); um["SubPixelOffset"] = (0, 0, 0, 0)
            um["FogControl"] = fog_ctl; um["MatColor"] = (1, 1, 1, 1); um["ColorBased"] = (0, 0, 0, 0)
            um["OverlayColor"] = (0, 0, 0, 0); um["ChangeColor"] = (1, 1, 1, 1); um["HudOpacity"] = (1, 1, 1, 1)
            um["UVAnimation"] = (0, 0, 1, 1); um["ActorFPEpsilon"] = (0.01, 0, 0, 0)
            day = max(0.0, min(1.0, math.cos(2 * math.pi * tod) * 3 + 0.4))
            sky = (1.0 if not self.mob_shade else 0.55) * (0.25 + 0.75 * day)
            um["TileLightColor"] = (sky, sky, sky, 1)
            self.p["mob"].use(um, [("s_MatTexture", self.mobtex), ("s_MatTexture1", self.mobtex)])
            self.p["mob"].draw(self.mob)
        if "clouds" in parts:
            GL.glEnable(0x0BE2); GL.glBlendFunc(0x0302, 0x0303)
            cm = np.eye(4, dtype=np.float32); cm[:3, 3] = (-cam[0], 128 - cam[1], -cam[2])
            uc = dict(common); uc["u_model[0]"] = gl_mat(cm)
            self.p["clouds"].use(uc); self.p["clouds"].draw(self.clouds)
        if "water" in parts:
            GL.glEnable(0x0BE2); GL.glBlendFunc(0x0302, 0x0303); GL.glDepthMask(0)
            self.p["water"].use(u, tex); self.p["water"].draw(water)
            GL.glDepthMask(1)
        GL.glDisable(0x0BE2)
        GL.glFinish()

    def frame_vanilla(self, tod, yaw, pitch=0.12, cam=(0.0, 9.0, 0.0), fov=70):
        """Minecraft SIN shader (referencia): cielo plano, luz del lightmap por pixel."""
        day = max(0.0, min(1.0, math.cos(2 * math.pi * tod) * 3 + 0.4))
        GL.glDeleteTextures(1, ctypes.byref(ctypes.c_uint(self.lmap)))
        self.lmap = make_tex(lightmap(day), nearest=False)
        sky = np.array([0.47, 0.65, 1.0]) * day + np.array([0.02, 0.02, 0.06]) * (1 - day)
        fog = (*(np.array([0.75, 0.85, 1.0]) * day + np.array([0.03, 0.04, 0.08]) * (1 - day)), 1)
        proj = perspective(fov, W / H, 0.1, 600)
        vp = proj @ look_rot(yaw, pitch)
        model = np.eye(4, dtype=np.float32); model[:3, 3] = -np.array(cam)
        u = {"FogAndDistanceControl": (0.5 + 20 / 128.0, 1.0, 128.0, 0), "FogColor": fog,
             "ViewPositionAndTime": (0, 0, 0, 0), "u_viewProj": gl_mat(vp), "u_model[0]": gl_mat(model)}
        GL.glBindFramebuffer(0x8D40, self.fbo); GL.glViewport(0, 0, W, H)
        GL.glClearColor(*[ctypes.c_float(float(c)) for c in sky], ctypes.c_float(1.0)); GL.glClear(0x4100)
        GL.glEnable(0x0B71); GL.glDepthMask(1); GL.glDepthFunc(0x0203)
        tex = [("s_MatTexture", self.tex), ("s_LightMapTexture", self.lmap)]
        opaque, alpha, water = self.scene
        v = self.p["vanilla"]
        v.use(u, tex); v.draw(opaque); v.draw(alpha)
        GL.glEnable(0x0BE2); GL.glBlendFunc(0x0302, 0x0303); GL.glDepthMask(0)
        v.draw(water); GL.glDepthMask(1); GL.glDisable(0x0BE2)
        GL.glFinish()
        # dejar el lightmap de dia para los shaders Umami (solo leen el brillo minimo)
        GL.glDeleteTextures(1, ctypes.byref(ctypes.c_uint(self.lmap)))
        self.lmap = make_tex(lightmap(1.0), nearest=False)

    def read(self):
        buf = np.empty((H, W, 4), np.uint8)
        GL.glReadPixels(0, 0, W, H, 0x1908, 0x1401, buf.ctypes.data)
        return Image.fromarray(buf[::-1, :, :3])


SHOTS = [  # nombre, hora (0 = mediodia), yaw, camara, pitch
    ("mediodia", 0.06, math.radians(200), (0.0, 9.0, 0.0), 0.12),
    ("atardecer", 0.235, math.radians(180), (0.0, 9.0, 0.0), 0.12),
    ("crepusculo", 0.262, math.radians(180), (0.0, 9.0, 0.0), 0.12),
    ("noche", 0.50, math.radians(160), (0.0, 9.0, 0.0), 0.12),
    ("amanecer", 0.765, math.radians(0), (0.0, 9.0, 0.0), 0.12),
    ("lluvia", 0.10, math.radians(200), (0.0, 9.0, 0.0), 0.12),
    ("sombra_arbol", 0.04, math.radians(235), (2.0, 10.0, 6.0), -0.35),
    ("antorcha_noche", 0.50, math.radians(225), (1.0, 8.5, 11.0), -0.30),
    ("mob_atardecer", 0.235, math.radians(200), (-1.5, 5.5, 5.0), -0.30),
    ("mob_mediodia", 0.06, math.radians(200), (-1.5, 5.5, 5.0), -0.30),
]


def arg(name, default):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "render"
    q = arg("--q", "DEFAULT")
    r = Renderer(q)
    os.makedirs(OUTDIR, exist_ok=True)
    if mode == "render":
        imgs = []
        for name, tod, yaw, cam, pitch in SHOTS:
            r.frame(tod, yaw, pitch=pitch, cam=cam, rain=1.0 if name == "lluvia" else 0.0)
            im = r.read(); im.save(os.path.join(OUTDIR, "preview_%s_%s.png" % (q, name)))
            imgs.append((name, im))
        # hoja de contacto
        tw, th = W // 2, H // 2
        sheet = Image.new("RGB", (tw * 2, th * ((len(imgs) + 1) // 2)))
        for i, (n, im) in enumerate(imgs):
            sheet.paste(im.resize((tw, th)), ((i % 2) * tw, (i // 2) * th))
        sheet.save(os.path.join(OUTDIR, "preview_%s_hoja.png" % q))
        print("ok", os.path.join(OUTDIR, "preview_%s_hoja.png" % q))
    elif mode == "compare":
        # mismas tomas, con y sin shader; guarda devtools/out/cmp_<q|vanilla>_<toma>.png
        for name, tod, yaw, cam, pitch in SHOTS:
            if name not in ("mediodia", "sombra_arbol", "atardecer", "noche", "antorcha_noche"):
                continue
            r.frame(tod, yaw, pitch=pitch, cam=cam,
                    parts=["sky", "stars", "sun", "clouds", "opaque", "alpha", "water"])  # sin mob: igual que la referencia
            r.read().save(os.path.join(OUTDIR, "cmp_%s_%s.png" % (arg("--tag", q), name)))
            if "--vanilla" in sys.argv:
                r.frame_vanilla(tod, yaw, pitch=pitch, cam=cam)
                r.read().save(os.path.join(OUTDIR, "cmp_vanilla_%s.png" % name))
        print("ok compare")
    elif mode == "bench":
        reps = int(arg("--n", "10"))
        TOD = float(arg("--tod", "-1")); RAIN = float(arg("--rain", "0"))
        def timed(parts, tod):
            if TOD >= 0: tod = TOD
            r.frame(tod, math.radians(180), parts=parts, rain=RAIN)
            ts = []
            for i in range(reps):
                t0 = time.perf_counter()
                r.frame(tod, math.radians(180), parts=parts, rain=RAIN)
                ts.append(time.perf_counter() - t0)
            ts.sort()
            return sum(ts[: max(1, reps // 2)]) / max(1, reps // 2) * 1000  # media de la mitad mas rapida
        base = timed(["none"], 0.235)
        tot = 0
        for part in arg("--parts", "null,vanilla,sky,sun,stars,clouds,opaque,alpha,water").split(","):
            tod = 0.5 if part == "stars" else 0.235
            v = timed([part], tod) - base
            tot += v
            if part == "null":
                null = v
                print("(terreno con shader nulo: %.2f ms)" % v)
                continue
            if part == "opaque":
                print("%-8s %7.2f ms   -> costo propio del shader: %.2f ms" % (part, v, v - null))
            else:
                print("%-8s %7.2f ms" % (part, v))
        print("TOTAL    %7.2f ms   (vacio %.2f ms)" % (tot, base))
