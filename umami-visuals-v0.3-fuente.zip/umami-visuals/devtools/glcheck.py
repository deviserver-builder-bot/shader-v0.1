#!/usr/bin/env python3
"""
glcheck - valida y mide los shaders de Umami Visuals SIN el compilador del juego.

1. Convierte cada .sc (dialecto bgfx) a GLSL ES 3.00 usando el preprocesador C,
   igual que hace shaderc para Android (perfil ESSL_300).
2. Compila y enlaza con Mesa (EGL surfaceless + GLES3) -> detecta errores reales.
3. Cuenta instrucciones ALU del NIR optimizado de Mesa (metrica de costo GPU).

Uso:  python3 devtools/glcheck.py            (todas las variantes)
      python3 devtools/glcheck.py --dump     (guarda el GLSL generado en devtools/out)
"""
import ctypes, os, re, subprocess, sys, json, itertools

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")
INC = os.path.join(ROOT, "include")
OUT = os.path.join(ROOT, "devtools", "out")

# variantes que interesan (pase x flags) por material
VARIANTS = {
    "RenderChunk": [["OPAQUE"], ["ALPHA_TEST"], ["TRANSPARENT"], ["OPAQUE", "SEASONS"],
                    ["ALPHA_TEST", "RENDER_AS_BILLBOARDS"], ["DEPTH_ONLY_OPAQUE"], ["DEPTH_ONLY"],
                    ["OPAQUE", "INSTANCING"], ["TRANSPARENT", "INSTANCING"], ["ALPHA_TEST", "SEASONS"],
                    ["TRANSPARENT", "SEASONS"], ["TRANSPARENT", "RENDER_AS_BILLBOARDS"]],
    "Sky": [[], ["INSTANCING"]],
    "SunMoon": [[], ["INSTANCING"]],
    "Stars": [[], ["INSTANCING"]],
    "Clouds": [[], ["INSTANCING"]],
    "Weather": [[], ["NO_OCCLUSION"], ["FLIP_OCCLUSION"], ["NO_VARIETY"], ["INSTANCING"]],
    "EndSky": [[], ["INSTANCING"]],
}
_ACT = [["OPAQUE"], ["ALPHA_TEST"], ["TRANSPARENT"], ["DEPTH_ONLY_OPAQUE"], ["DEPTH_ONLY"],
        ["OPAQUE", "CHANGE_COLOR"], ["ALPHA_TEST", "CHANGE_COLOR_MULTI"], ["OPAQUE", "EMISSIVE"],
        ["ALPHA_TEST", "EMISSIVE_ONLY"], ["OPAQUE", "MASKED_MULTITEXTURE"], ["OPAQUE", "INSTANCING"],
        ["OPAQUE", "FANCY"], ["TRANSPARENT", "CHANGE_COLOR"]]
_ITEM = [["OPAQUE"], ["ALPHA_TEST"], ["TRANSPARENT"], ["DEPTH_ONLY"], ["OPAQUE", "MULTI_COLOR_TINT"],
         ["OPAQUE", "INSTANCING"], ["OPAQUE", "FANCY"]]
for _m in ("Actor", "ActorGlint", "ActorMultiTexture"):
    VARIANTS[_m] = _ACT
for _m in ("ItemInHandColor", "ItemInHandTextured", "ItemInHandColorGlint"):
    VARIANTS[_m] = _ITEM
QUALITY = ["ULTRA", "DEFAULT", "BONITO", "NOCHE_CLARA", "SIN_NIEBLA", "SIN_MOVIMIENTO", "DIAGNOSTICO"]
if "--rapido" in sys.argv:
    QUALITY = ["ULTRA", "DEFAULT", "BONITO"]


def parse_varyings(mat):
    v = {}
    for line in open(os.path.join(SRC, "materials", mat, "varying.def.sc")):
        line = line.split("//")[0].strip().rstrip(";")
        if not line or ":" not in line:
            continue
        decl = line.split(":")[0].split()
        qual = decl[0] if decl[0] in ("centroid", "flat") else ""
        typ, name = decl[-2], decl[-1]
        v[name] = (qual, typ)
    return v


def preprocess(mat, stage, defines):
    path = os.path.join(SRC, "materials", mat, stage + ".sc")
    args = ["cpp", "-P", "-undef", "-nostdinc", "-w", "-I", SRC, "-I", INC,
            "-DBGFX_SHADER_LANGUAGE_GLSL=300",
            "-DBGFX_SHADER_TYPE_VERTEX=%d" % (stage == "vertex"),
            "-DBGFX_SHADER_TYPE_FRAGMENT=%d" % (stage == "fragment")]
    args += ["-D" + d for d in defines]
    r = subprocess.run(args + [path], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr)
    return r.stdout


def to_essl(mat, stage, defines):
    vary = parse_varyings(mat)
    code = preprocess(mat, stage, defines)
    decls, body = [], []
    for line in code.splitlines():
        s = line.strip()
        if s.startswith("$input") or s.startswith("$output"):
            kind = s.split()[0]
            for n in s[len(kind):].split(","):
                n = n.strip()
                if not n:
                    continue
                qual, typ = vary[n]
                if n.startswith("a_") or n.startswith("i_"):
                    decls.append("in %s %s;" % (typ, n))
                else:
                    io = "out" if stage == "vertex" else "in"
                    decls.append(("%s %s %s %s;" % (qual, io, typ, n)).strip())
        else:
            body.append(line)
    head = ["#version 300 es", "precision highp float;", "precision highp int;"]
    if stage == "fragment":
        head += ["out vec4 bgfx_FragColor;", "#define gl_FragColor bgfx_FragColor"]
    return "\n".join(head + decls + body) + "\n"


# ------------------------------------------------------------------ EGL/GLES
EGL = ctypes.CDLL("libEGL.so.1")
GL = ctypes.CDLL("libGLESv2.so.2")
EGL.eglGetProcAddress.restype = ctypes.c_void_p
EGL.eglGetProcAddress.argtypes = [ctypes.c_char_p]
EGL.eglGetPlatformDisplayEXT = None


def init_gl():
    get_plat = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p)(
        EGL.eglGetProcAddress(b"eglGetPlatformDisplayEXT"))
    dpy = get_plat(0x31DD, None, None)  # EGL_PLATFORM_SURFACELESS_MESA
    EGL.eglInitialize.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    assert EGL.eglInitialize(dpy, None, None)
    EGL.eglBindAPI(0x30A0)  # EGL_OPENGL_ES_API
    attrs = (ctypes.c_int * 3)(0x3040, 0x0040, 0x3038)  # RENDERABLE_TYPE=ES3
    cfg = ctypes.c_void_p(); n = ctypes.c_int()
    EGL.eglChooseConfig.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
    EGL.eglChooseConfig(dpy, attrs, ctypes.byref(cfg), 1, ctypes.byref(n))
    cattrs = (ctypes.c_int * 3)(0x3098, 3, 0x3038)  # CONTEXT_MAJOR_VERSION=3
    EGL.eglCreateContext.restype = ctypes.c_void_p
    EGL.eglCreateContext.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    ctx = EGL.eglCreateContext(dpy, cfg if n.value else None, None, cattrs)
    EGL.eglMakeCurrent.argtypes = [ctypes.c_void_p] * 4
    assert EGL.eglMakeCurrent(dpy, None, None, ctx), "no se pudo activar contexto GLES"
    GL.glGetString.restype = ctypes.c_char_p
    return GL.glGetString(0x1F01).decode()  # GL_RENDERER


def compile_shader(src, stage):
    sh = GL.glCreateShader(0x8B31 if stage == "vertex" else 0x8B30)
    b = src.encode()
    arr = (ctypes.c_char_p * 1)(b)
    GL.glShaderSource(sh, 1, arr, None)
    GL.glCompileShader(sh)
    ok = ctypes.c_int(); GL.glGetShaderiv(sh, 0x8B81, ctypes.byref(ok))
    log = ctypes.create_string_buffer(8192)
    GL.glGetShaderInfoLog(sh, 8192, None, log)
    return sh, bool(ok.value), log.value.decode(errors="replace")


def link(vs, fs):
    p = GL.glCreateProgram()
    GL.glAttachShader(p, vs); GL.glAttachShader(p, fs)
    GL.glLinkProgram(p)
    ok = ctypes.c_int(); GL.glGetProgramiv(p, 0x8B82, ctypes.byref(ok))
    log = ctypes.create_string_buffer(8192)
    GL.glGetProgramInfoLog(p, 8192, None, log)
    return p, bool(ok.value), log.value.decode(errors="replace")


def build_variant(mat, defs, dump=False):
    srcs = {st: to_essl(mat, st, defs) for st in ("vertex", "fragment")}
    if dump:
        os.makedirs(OUT, exist_ok=True)
        tag = "_".join([mat] + defs)
        for st, s in srcs.items():
            open(os.path.join(OUT, "%s.%s.glsl" % (tag, st[:4])), "w").write(s)
    res = {}
    shaders = []
    for st, s in srcs.items():
        sh, ok, log = compile_shader(s, st)
        res[st] = (ok, log)
        shaders.append(sh)
    p, ok, log = link(*shaders)
    res["link"] = (ok, log)
    return res, srcs, p


if __name__ == "__main__":
    dump = "--dump" in sys.argv
    print("GPU de prueba:", init_gl())
    fails = 0
    for q in QUALITY:
        for mat, vs in VARIANTS.items():
            for v in vs:
                defs = [q] + v
                res, _, _ = build_variant(mat, defs, dump)
                bad = [k for k, (ok, _) in res.items() if not ok]
                tag = "%-8s %-12s %s" % (q, mat, "+".join(v) or "-")
                if bad:
                    fails += 1
                    print("FALLA ", tag)
                    for k in bad:
                        print("   [%s] %s" % (k, res[k][1].strip()[:1500]))
                else:
                    print("ok    ", tag)
    print("\n%d fallas" % fails)
    sys.exit(1 if fails else 0)
