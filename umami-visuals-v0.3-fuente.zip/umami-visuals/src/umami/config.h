#ifndef UMAMI_CONFIG_H
#define UMAMI_CONFIG_H

/*
  Umami Visuals - configuracion
  Shader ligero para Minecraft Bedrock (RenderDragon) pensado para GPUs
  moviles de gama baja (Mali-G57 MC2 / Helio G99, Infinix Note 30).

  Regla de oro: todo lo caro se calcula por VERTICE, nunca por pixel.
  El fragment shader del terreno hace solo: 1 textura + 2 MAD + 1 mix.
*/

// ---- Niveles de calidad y opciones (las activa el subpack elegido en el juego) ----
// ULTRA          : lo minimo posible, maximo FPS
// DEFAULT        : equilibrado (recomendado para Infinix Note 30)
// BONITO         : + brillo por pixel al sol y destello del sol en el agua por pixel
// NOCHE_CLARA    : equilibrado + noches mas visibles
// SIN_NIEBLA     : equilibrado sin niebla ni bruma
// SIN_MOVIMIENTO : equilibrado sin olas, plantas ni antorchas que titilan
// DIAGNOSTICO    : pinta el mundo segun lo que detecta el shader (para reportar fallas)

#if defined(ULTRA)
  #define UM_WATER_WAVES    0
  #define UM_WATER_SPEC     1   // destello por vertice (barato)
  #define UM_PIXEL_SHINE    0
  #define UM_SKY_HALO       0
  #define UM_SKY_EXTRAS     0   // sin cinturon rosado ni oscurecer bajo el horizonte
  #define UM_TEX_DEFINITION 0
  #define UM_PLANT_WAVES    0
  #define UM_TORCH_FLICKER  0
#elif defined(BONITO)
  #define UM_WATER_WAVES    1
  #define UM_WATER_SPEC     1
  #define UM_WATER_PIXEL_SPEC 1   // destello del sol en el agua calculado por pixel (suave)
  #define UM_PIXEL_SHINE    1
  #define UM_SKY_HALO       1
  #define UM_SKY_EXTRAS     1
  #define UM_TEX_DEFINITION 1
  #define UM_PLANT_WAVES    1
  #define UM_TORCH_FLICKER  1
#else
  #define UM_WATER_WAVES    1
  #define UM_WATER_SPEC     1
  #define UM_PIXEL_SHINE    0
  #define UM_SKY_HALO       1
  #define UM_SKY_EXTRAS     1
  #define UM_TEX_DEFINITION 1
  #define UM_PLANT_WAVES    1
  #define UM_TORCH_FLICKER  1
#endif

#ifndef UM_WATER_PIXEL_SPEC
  #define UM_WATER_PIXEL_SPEC 0
#endif

#ifdef SIN_MOVIMIENTO
  #undef UM_WATER_WAVES
  #undef UM_PLANT_WAVES
  #undef UM_TORCH_FLICKER
  #define UM_WATER_WAVES   0
  #define UM_PLANT_WAVES   0
  #define UM_TORCH_FLICKER 0
#endif

#ifdef SIN_NIEBLA
  #define UM_FOG 0
#else
  #define UM_FOG 1
#endif

#ifdef NOCHE_CLARA
  #define UM_NIGHT_BOOST 1
#else
  #define UM_NIGHT_BOOST 0
#endif

// el deslizador de brillo del juego se respeta en todos los niveles (1 lectura por vertice)
#define UM_USE_BRIGHTNESS 1

// efectos baratos (por vertice) activos en todos los niveles
#define UM_SIDE_SUN      1   // sol alto ilumina el suelo; sol bajo ilumina las paredes
#define UM_WET_RAIN      1   // superficies al aire libre se ven mojadas con lluvia
#define UM_LIGHTS_IN_FOG 1   // de noche las zonas iluminadas por antorchas atraviesan la niebla

// ---- Trayectoria del sol (grados). Debe coincidir en SunMoon y el resto ----
#define UM_SUN_TILT   0.42   // ~24 grados: la luz llega inclinada, se ve mas bonito
#define UM_COS_TILT   0.91305  // cos(UM_SUN_TILT) precalculado
#define UM_SIN_TILT   0.40776  // sin(UM_SUN_TILT) precalculado

// ---- Cielo de dia ----
#define UM_DAY_ZENITH   vec3(0.16, 0.40, 0.86)
#define UM_DAY_HORIZON  vec3(0.66, 0.82, 1.00)
#define UM_DAY_GLOW     vec3(1.00, 0.92, 0.75)

// ---- Atardecer / amanecer ----
#define UM_SET_ZENITH   vec3(0.24, 0.20, 0.50)
#define UM_SET_HORIZON  vec3(1.00, 0.48, 0.20)
#define UM_SET_GLOW     vec3(1.00, 0.40, 0.08)
#define UM_SET_PINK     vec3(0.86, 0.46, 0.62)   // "cinturon de Venus" del lado opuesto

// ---- Noche ----
#define UM_NIGHT_ZENITH  vec3(0.012, 0.018, 0.060)
#define UM_NIGHT_HORIZON vec3(0.050, 0.075, 0.165)
#define UM_MOON_GLOW     vec3(0.30, 0.40, 0.62)

// ---- Luz sobre el mundo ----
#define UM_SUNLIGHT_DAY   vec3(1.00, 0.93, 0.80)
#define UM_SUNLIGHT_SET   vec3(1.05, 0.60, 0.32)
#define UM_MOONLIGHT      vec3(0.17, 0.21, 0.33)
#define UM_TORCH_COLOR    vec3(1.00, 0.62, 0.30)
#define UM_TORCH_POWER    1.00
#define UM_SHADOW_SIDE    0.74   // caras laterales reciben menos sol
// Calibrado contra Minecraft original: a pleno sol sol+cielo = x1.0 (color real
// de la textura, apenas calido); en sombra x0.55 con un toque frio.
#define UM_SUN_STRENGTH   0.32
#define UM_DAY_AMBIENT    vec3(0.68, 0.71, 0.75)
#define UM_NIGHT_AMBIENT  vec3(0.05, 0.07, 0.15)
#define UM_SET_AMBIENT    vec3(0.62, 0.50, 0.46)
#define UM_MIN_LIGHT      vec3(0.060, 0.065, 0.085)  // solo aclara zonas oscuras
// definicion de texturas: 0 = original, 0.3 = un poco mas nitidas (Ultra ligero la apaga)
#define UM_TEX_CONTRAST 0.30

#define UM_NETHER_AMBIENT vec3(0.62, 0.42, 0.34)
#define UM_END_AMBIENT    vec3(0.42, 0.38, 0.58)
#define UM_END_ZENITH     vec3(0.05, 0.02, 0.09)
#define UM_END_HORIZON    vec3(0.22, 0.12, 0.30)

// ---- Luz de noche extra (subpack Noche clara) ----
#define UM_NIGHT_BOOST_COL vec3(0.20, 0.23, 0.32)

// ---- Color de niebla del bioma "planicies" (referencia neutra para el tinte por bioma) ----
#define UM_BIOME_INV_REF  vec3(1.49, 1.22, 1.00)   // 1 / color de niebla de planicies (0.67, 0.82, 1.0)
#define UM_BIOME_TINT     0.40   // cuanto toma el horizonte el color propio de cada bioma

// ---- Movimiento ----
#define UM_LEAF_WAVE   0.030
#define UM_GRASS_WAVE  0.065
#define UM_WAVE_RANGE  40.0    // bloques: mas lejos no se mueven (ahorra calculo)

// ---- Agua ----
#define UM_WATER_WAVE_HEIGHT 0.045
#define UM_WATER_FRESNEL     0.80

#endif
