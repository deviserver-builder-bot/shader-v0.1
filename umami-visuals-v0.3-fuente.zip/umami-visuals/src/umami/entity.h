#ifndef UMAMI_ENTITY_H
#define UMAMI_ENTITY_H

#include "sky.h"

// ---------------------------------------------------------------------------
// Luz y niebla para mobs, jugadores y objetos en la mano.
// Todo por vertice. El pixel hace lo mismo que el Minecraft original:
// textura * luz + mezcla de niebla.
//
// TileLightColor es la luz que el juego calculo en la posicion del mob
// (ya incluye dia/noche). Se separa en "cielo" y "antorcha":
//   .b ~ luz del cielo (blanca)   .r - .b ~ luz de antorcha (calida)
// ---------------------------------------------------------------------------

struct um_entity {
  vec3 light;
  vec4 fog;     // rgb color, a cantidad
};

um_entity umEntityShade(
  vec3 N, vec3 relPos, vec4 tileLight, vec4 fogColor, vec3 fogCtl,
  float timeOfDay, float moonPhase, vec3 camPos, float t
) {
  um_entity E;

  float rain = umRain(fogCtl);
  bool underwater = false;
  bool nether = false;
  if (fogCtl.x < 0.14) {
    underwater = umIsUnderwater(fogColor.rgb, fogCtl.xy);
    nether = !underwater && umIsNether(fogColor.rgb, fogCtl.xy);
  }
  bool theEnd = umIsEnd(fogColor.rgb);

  um_time T = umTime(timeOfDay, rain);
  T.moon = umMoonIllum(moonPhase);
  um_light L = umLightColors(T, rain);

  float torchAmt = clamp((tileLight.r - tileLight.b)*3.0, 0.0, 1.0);
  // quitar el oscurecimiento de dia/noche que ya trae el juego (lo pone nuestro sol/luna)
  float skyAmt = clamp(tileLight.b/mix(0.25, 1.0, T.day), 0.0, 1.0);

  vec3 light;
  if (nether || theEnd) {
    vec3 hue = fogColor.rgb/max(max(fogColor.r, max(fogColor.g, fogColor.b)), 0.05);
    vec3 amb = nether ? mix(UM_NETHER_AMBIENT, hue*0.65, 0.45) : UM_END_AMBIENT;
    light = amb*(0.75 + 0.25*N.y) + UM_TORCH_COLOR*(torchAmt*UM_TORCH_POWER);
  } else {
    float sunMask = clamp((skyAmt - 0.865)*12.0, 0.0, 1.0);
    // sol real por la normal: la cara que mira al sol se ilumina, la de atras queda en sombra
    float facing = max(dot(N, T.light.xyz), 0.0);
    vec3 direct = L.sun*(sunMask*(0.25 + 1.35*facing));
    vec3 ambient = L.ambient*(skyAmt*(0.35 + 0.65*skyAmt)*(0.80 + 0.20*N.y));
    light = direct + ambient;
    if (rain > 0.01) light = umRainGrey(light, rain);
    light += UM_TORCH_COLOR*(torchAmt*UM_TORCH_POWER*(1.0 - 0.6*sunMask*T.day));
    #if UM_NIGHT_BOOST
      light += UM_NIGHT_BOOST_COL*((1.0 - T.day)*skyAmt);
    #endif
    light += UM_MIN_LIGHT*max(1.0 - light.g, 0.0) + vec3_splat(0.04);
  }

  if (underwater) {
    vec3 gp = relPos + camPos;
    vec2 w = abs(fract(vec2(gp.x*0.27 + t*0.25, gp.z*0.31 - t*0.2))*2.0 - 1.0);
    light *= vec3(0.55, 0.80, 1.00);
    light += vec3(0.10, 0.16, 0.20)*(w.x*w.y);
  }
  E.light = min(light, vec3_splat(1.15));

  // niebla: misma que el terreno
  float camDis = length(relPos);
  vec3 dir = relPos/max(camDis, 0.001);
  float relDist = camDis/fogCtl.z;
  float fogA = clamp((relDist - fogCtl.x)/(fogCtl.y - fogCtl.x), 0.0, 1.0);
  fogA = fogA*fogA*(3.0 - 2.0*fogA);
  vec3 fogCol = fogColor.rgb;
  if (!(nether || theEnd || underwater)) {
    #if UM_FOG
      float hz = max(relDist - 0.25, 0.0);
      fogA = max(fogA, min(hz*hz*(0.39 + 0.62*T.set + 0.8*rain), 0.85));
    #else
      fogA = fogA*fogA;
    #endif
    if (fogA > 0.004) {
      fogCol = umFogColor(dir, T, rain)*umBiomeTint(fogColor.rgb, T.day, T.set);
    }
  }
  E.fog = vec4(fogCol, fogA);
  return E;
}

#endif
