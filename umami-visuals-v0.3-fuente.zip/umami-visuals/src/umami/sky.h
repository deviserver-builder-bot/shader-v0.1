#ifndef UMAMI_SKY_H
#define UMAMI_SKY_H

#include "config.h"

#define UM_PI 3.141592

float umLum(vec3 c) { return dot(c, vec3(0.21, 0.71, 0.08)); }

// sin y cos de 2*PI*x a la vez, con una parabola refinada (error < 0.1%).
// Mucho mas barato que sin()+cos() reales en GPUs moviles.
vec2 umSinCos2Pi(float x) {
  vec2 w = fract(vec2(x, x + 0.25) + 0.5)*2.0 - 1.0;   // angulo/PI en [-1,1)
  vec2 y = 4.0*w*(1.0 - abs(w));
  return y + 0.225*(y*abs(y) - y);
}

// ---------------------------------------------------------------------------
// Deteccion de entorno a partir del color/control de niebla.
// Logica basada en Newb Shader (MIT, devendrn) - ver LICENSE-newb-tool.txt
// ---------------------------------------------------------------------------
bool umIsUnderwater(vec3 fogCol, vec2 fogCtl) {
  return fogCtl.x == 0.0 && fogCtl.y < 0.8 && (fogCol.b > fogCol.r || fogCol.g > fogCol.r);
}

bool umIsNether(vec3 fogCol, vec2 fogCtl) {
  float expectedX = 0.029 + 0.09*fogCtl.y*fogCtl.y;
  bool ctl = fogCtl.x < 0.14 && abs(fogCtl.x - expectedX) < 0.02;
  bool lava = fogCtl.x == 0.0 && fogCol.b == 0.0 && fogCol.g < 0.18 && fogCol.r - fogCol.g > 0.1;
  return (ctl && (fogCol.r + fogCol.g) > 0.0) || lava;
}

bool umIsEnd(vec3 fogCol) {
  return fogCol.r == fogCol.b && (fogCol.r - fogCol.g > 0.24 || (fogCol.g == 0.0 && fogCol.r > 0.1));
}

// onda suave -1..1 sin usar sin(): triangular redondeada (barata en Mali)
float umWave(float x) {
  float w = abs(fract(x) * 2.0 - 1.0) * 2.0 - 1.0;
  return w*(2.0 - abs(w));
}

// brillo de la luna segun su fase (0 = llena .. 4 = nueva .. 7). Sin trigonometria:
// u = 1 en luna llena, 0 en luna nueva, con curva suave.
float umMoonIllum(float phase) {
  float u = abs(clamp(phase, 0.0, 8.0) - 4.0)*0.25;
  u = u*u*(3.0 - 2.0*u);
  return 0.30 + 0.70*u;
}

// tinte del cielo/niebla segun el bioma (desierto mas calido, pantano mas verdoso...)
// compara el color de niebla que el juego da a cada bioma con el de planicies.
vec3 umBiomeTint(vec3 fogCol, float day, float set) {
  vec3 tint = clamp(fogCol*UM_BIOME_INV_REF, vec3_splat(0.7), vec3_splat(1.4));
  return mix(vec3_splat(1.0), tint, UM_BIOME_TINT*day*(1.0 - set));
}

float umRain(vec3 fogCtl) {
  vec2 clear = vec2(0.5 + 20.0/fogCtl.z, 1.0);
  vec2 f = clamp((fogCtl.xy - clear)/(vec2(0.23, 0.70) - clear), 0.0, 1.0);
  float v = f.x*f.y;
  return v*v*(3.0 - 2.0*v);
}

// ---------------------------------------------------------------------------
// Paleta del cielo. Se calcula SOLO en vertex shaders (barata a ese nivel)
// y se pasa por varyings a los pixeles.
// ---------------------------------------------------------------------------
// --- tiempo: lo minimo que todos necesitan (1 cos + 1 sin) ---
struct um_time {
  float d;      // altura del sol (-1..1)
  float day;    // 0 noche .. 1 dia
  float set;    // cantidad de atardecer/amanecer (ya reducida por lluvia)
  vec4 light;   // xyz: direccion hacia afuera del astro principal, w = set
  float moon;   // brillo de la luna por su fase (0.3 .. 1)
};

um_time umTime(float timeOfDay, float rain) {
  um_time T;
  vec2 sc = umSinCos2Pi(timeOfDay);
  float sa = sc.x;
  float d = sc.y;
  T.d = d;
  float dayW = clamp(d*3.2 + 0.30, 0.0, 1.0);
  T.day = dayW*dayW*(3.0 - 2.0*dayW);
  float set = clamp(1.0 - abs(d - 0.04)*4.5, 0.0, 1.0);
  T.set = set*set*(3.0 - 2.0*set)*(1.0 - rain);
  // de noche el astro principal es la luna (justo opuesta al sol)
  float flip = d < -0.06 ? -1.0 : 1.0;
  T.light = vec4(flip*vec3(-sa, UM_COS_TILT*d, UM_SIN_TILT*d), T.set);
  T.moon = 1.0;
  return T;
}

// --- luz sobre el mundo (terreno): barata, sin colores del cielo ---
struct um_light {
  vec3 sun;      // luz directa
  vec3 ambient;  // luz del cielo en las sombras
};

um_light umLightColors(um_time T, float rain) {
  um_light L;
  float sunHigh = clamp(T.d*2.4, 0.0, 1.0);
  float sunVis = clamp((T.d + 0.06)*9.0, 0.0, 1.0);
  float moonVis = clamp((-T.d - 0.04)*5.0, 0.0, 1.0);
  L.sun = mix(UM_SUNLIGHT_SET, UM_SUNLIGHT_DAY, sunHigh)*(sunVis*sunVis*UM_SUN_STRENGTH) + UM_MOONLIGHT*(moonVis*T.moon);
  L.ambient = mix(UM_NIGHT_AMBIENT*(0.75 + 0.25*T.moon), UM_DAY_AMBIENT, T.day);
  L.ambient = mix(L.ambient, UM_SET_AMBIENT, T.set*0.7);
  // con lluvia el sol directo se debilita; el gris se aplica una sola vez al final (umRainGrey)
  L.sun *= 1.0 - 0.55*rain;
  return L;
}

// gris de lluvia aplicado una sola vez a la luz final
vec3 umRainGrey(vec3 c, float rain) {
  return mix(c, vec3_splat(umLum(c)*0.92), rain*0.8);
}

// --- colores del cielo: solo donde se ven (cielo, niebla lejana, agua, nubes) ---
struct um_skycol {
  vec3 zen;
  vec3 hor;
  vec3 glow;
};

um_skycol umSkyColors(um_time T, float rain) {
  um_skycol C;
  C.zen = mix(UM_NIGHT_ZENITH, UM_DAY_ZENITH, T.day);
  C.zen = mix(C.zen, UM_SET_ZENITH, T.set*0.55);
  C.hor = mix(UM_NIGHT_HORIZON, UM_DAY_HORIZON, T.day);
  C.hor = mix(C.hor, UM_SET_HORIZON, T.set*0.85);
  C.glow = mix(UM_MOON_GLOW*(0.35*T.moon), UM_DAY_GLOW, T.day);
  C.glow = mix(C.glow, UM_SET_GLOW, T.set);
  float r8 = rain*0.8;
  C.zen = mix(C.zen, vec3_splat(umLum(C.zen))*0.8, r8);
  C.hor = mix(C.hor, vec3_splat(umLum(C.hor))*0.8, r8);
  C.glow *= 1.0 - 0.85*rain;
  return C;
}

// --- color de niebla: version reducida del cielo cerca del horizonte ---
// La niebla solo se ve a lo lejos (cerca del horizonte), asi que no necesita
// cenit, halo ni cinturon rosado. ~3 veces mas barata que umSkyColor.
vec3 umFogColor(vec3 dir, um_time T, float rain) {
  vec3 hor = mix(UM_NIGHT_HORIZON, UM_DAY_HORIZON, T.day);
  hor = mix(hor, UM_SET_HORIZON, T.set*0.85);
  vec3 glow = mix(UM_DAY_GLOW, UM_SET_GLOW, T.set)*T.day;
  float mu = max(dot(dir, T.light.xyz), 0.0);
  mu *= mu; mu *= mu;
  vec3 col = hor + glow*(mu*(0.16 + 0.62*T.set));
  return mix(col, vec3_splat(umLum(col)*0.8), rain*0.8);
}

// ---------------------------------------------------------------------------
// Color del cielo en una direccion (hacia afuera). ~20 operaciones.
// Se usa por pixel en el cielo y por vertice en niebla/reflejos/nubes.
// ---------------------------------------------------------------------------
vec3 umSkyColor(vec3 dir, vec3 zen, vec3 hor, vec3 glow, vec4 light) {
  float h = 1.0 - clamp(dir.y, 0.0, 1.0);   // 0 = cenit, 1 = horizonte
  float h2 = h*h;
  vec3 col = mix(zen, hor, h2*h);

  float mu = max(dot(dir, light.xyz), 0.0);
  float m2 = mu*mu;
  float m4 = m2*m2;
  float m8 = m4*m4;

  // resplandor amplio pegado al horizonte (fuerte en atardecer)
  col += glow*(m4*h2*(0.16 + 0.62*light.w));

  #if UM_SKY_HALO
    // halo cercano al astro
    float m32 = m8*m8; m32 *= m32;
    col += glow*(m8*0.10 + m32*0.55);
  #else
    col += glow*(m8*0.18);
  #endif

  #if UM_SKY_EXTRAS
    // lado opuesto al sol en el atardecer: rosado suave
    col = mix(col, UM_SET_PINK, light.w*h2*(1.0 - mu)*0.28);
    // bajo el horizonte un poco mas oscuro
    col *= 1.0 - 0.45*clamp(-dir.y*2.5, 0.0, 1.0);
  #endif
  return col;
}

// misma funcion en media precision para los pixeles del cielo (FP16 = el doble de rapido en Mali)
mediump vec3 umSkyColorM(mediump vec3 dir, mediump vec3 zen, mediump vec3 hor, mediump vec3 glow, mediump vec4 light) {
  mediump float h = 1.0 - clamp(dir.y, 0.0, 1.0);   // 0 = cenit, 1 = horizonte
  mediump float h2 = h*h;
  mediump vec3 col = mix(zen, hor, h2*h);

  mediump float mu = max(dot(dir, light.xyz), 0.0);
  mediump float m2 = mu*mu;
  mediump float m4 = m2*m2;
  mediump float m8 = m4*m4;

  // resplandor amplio pegado al horizonte (fuerte en atardecer)
  col += glow*(m4*h2*(0.16 + 0.62*light.w));

  #if UM_SKY_HALO
    // halo cercano al astro
    mediump float m32 = m8*m8; m32 *= m32;
    col += glow*(m8*0.10 + m32*0.55);
  #else
    col += glow*(m8*0.18);
  #endif

  #if UM_SKY_EXTRAS
    // lado opuesto al sol en el atardecer: rosado suave
    col = mix(col, UM_SET_PINK, light.w*h2*(1.0 - mu)*0.28);
    // bajo el horizonte un poco mas oscuro
    col *= 1.0 - 0.45*clamp(-dir.y*2.5, 0.0, 1.0);
  #endif
  return col;
}

#endif
