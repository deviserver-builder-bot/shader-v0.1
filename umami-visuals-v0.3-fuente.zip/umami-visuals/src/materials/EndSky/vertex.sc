$input a_texcoord0, a_position
#ifdef INSTANCING
  $input i_data0, i_data1, i_data2, i_data3
#endif
$output v_dir, v_texcoord0

#include <bgfx_shader.sh>

uniform vec4 ViewPositionAndTime;

// Cielo del End: degradado morado profundo + las estrellas del juego, girando muy lento.
void main() {
  #ifdef INSTANCING
    mat4 model = mtxFromCols(i_data0, i_data1, i_data2, i_data3);
  #else
    mat4 model = u_model[0];
  #endif

  vec3 pos = mul(model, vec4(a_position, 1.0)).xyz;

  // una vuelta completa por hora
  highp float t = 0.00174533*ViewPositionAndTime.w;
  float s = sin(t);
  float c = cos(t);
  pos.xz = mul(mtxFromRows(vec2(c, -s), vec2(s, c)), pos.xz);

  v_texcoord0 = 2.0*a_texcoord0;
  v_dir = pos;
  gl_Position = mul(u_viewProj, vec4(pos, 1.0));
}
