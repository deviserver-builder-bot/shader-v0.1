#ifndef INSTANCING
$input v_dir, v_texcoord0
#endif

#include <bgfx_shader.sh>

#ifndef INSTANCING
  #include <umami/config.h>
  SAMPLER2D_AUTOREG(s_SkyTexture);
#endif

void main() {
  #ifndef INSTANCING
    mediump vec4 stars = texture2D(s_SkyTexture, v_texcoord0);
    mediump float y = normalize(v_dir).y;
    mediump vec3 col = mix(UM_END_HORIZON, UM_END_ZENITH, min(abs(y)*1.6, 1.0));
    col += stars.rgb*1.5;
    gl_FragColor = vec4(col, 1.0);
  #else
    gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
  #endif
}
