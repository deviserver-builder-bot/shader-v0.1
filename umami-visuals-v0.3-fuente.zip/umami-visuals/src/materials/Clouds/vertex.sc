$input a_color0, a_position
#ifdef INSTANCING
  $input i_data0, i_data1, i_data2, i_data3
#endif
$output v_color0

#include <bgfx_shader.sh>
#include <umami/sky.h>

uniform vec4 FogAndDistanceControl;
uniform vec4 TimeOfDay;
uniform vec4 MoonPhase;

void main() {
  #ifdef INSTANCING
    mat4 model = mtxFromCols(i_data0, i_data1, i_data2, i_data3);
  #else
    mat4 model = u_model[0];
  #endif

  float rain = umRain(FogAndDistanceControl.xyz);
  um_time T = umTime(TimeOfDay.x, rain);
  T.moon = umMoonIllum(MoonPhase.x);
  um_light L = umLightColors(T, rain);

  vec3 worldPos = mul(model, vec4(a_position, 1.0)).xyz;
  vec3 dir = normalize(worldPos);

  // base: el color del horizonte en esa direccion (incluye el resplandor del sol)
  vec3 col = umFogColor(dir, T, rain)*0.72 + vec3(0.05, 0.06, 0.08);
  // parte de arriba iluminada por el sol; la de abajo toma el tono del atardecer
  float top = clamp(a_position.y, 0.0, 1.0);
  col += umRainGrey(L.sun, rain)*(0.32 + 0.28*top);
  col += UM_SET_GLOW*(T.set*0.45*(1.0 - top));
  // sombreado por cara que trae el juego + lluvia
  col *= (0.72 + 0.28*a_color0.g)*(1.0 - 0.55*rain);

  // desvanecer a lo lejos
  float fade = clamp(2.0 - length(worldPos*vec3(0.005, 0.002, 0.005)), 0.0, 1.0);

  // la base de la nube es mas transparente: bordes suaves en vez de un bloque solido
  float alpha = (0.70 + 0.20*rain)*(0.78 + 0.22*top);
  v_color0 = vec4(col, alpha*fade);
  gl_Position = mul(u_viewProj, vec4(worldPos, 1.0));
}
