$input v_color0, v_texcoord0
#ifdef SEASONS
  $input v_color1
#endif
#ifdef TRANSPARENT
  $input v_refl
  #include <umami/config.h>
  #if UM_WATER_PIXEL_SPEC
    $input v_wpos, v_sun
  #endif
#else
  $input v_fog
#endif

#include <bgfx_shader.sh>
#include <umami/config.h>

SAMPLER2D_AUTOREG(s_MatTexture);
SAMPLER2D_AUTOREG(s_SeasonsTexture);

#if defined(TRANSPARENT) && UM_WATER_PIXEL_SPEC
  uniform vec4 CameraPosition;
  uniform vec4 ViewPositionAndTime;
#endif

// Fragment del terreno: lo mas barato posible.
// 1 lectura de textura, 1 MAD de definicion + 1 multiplicacion, (agua: +1 suma), 1 mezcla de niebla.

void main() {
  #if defined(DEPTH_ONLY_OPAQUE) || defined(DEPTH_ONLY) || defined(INSTANCING)
    gl_FragColor = vec4(1.0, 1.0, 1.0, 1.0);
    return;
  #else

  mediump vec4 diffuse = texture2D(s_MatTexture, v_texcoord0);

  #ifdef ALPHA_TEST
    if (diffuse.a < 0.5) {
      discard;
    }
  #endif

  #if defined(SEASONS) && (defined(OPAQUE) || defined(ALPHA_TEST))
    diffuse.rgb *= mix(vec3(1.0, 1.0, 1.0), texture2D(s_SeasonsTexture, v_color1.xy).rgb*2.0, v_color1.z);
  #endif

  #ifdef TRANSPARENT
    diffuse.rgb = diffuse.rgb*v_color0.rgb + v_refl.rgb;
    diffuse.a = max(diffuse.a*v_color0.a, v_refl.a);
    #if UM_WATER_PIXEL_SPEC
      // destello del sol suave por pixel (solo nivel Bonito y solo en agua: v_sun.w > 0)
      if (v_sun.w > 0.001) {
        vec3 d = normalize(v_wpos.xyz);
        vec2 q = v_wpos.xz + CameraPosition.xz;
        highp float tt = ViewPositionAndTime.w;
        vec2 w = abs(fract(vec2(q.x*0.61 + tt*0.31, q.y*0.53 - tt*0.27))*2.0 - 1.0) - 0.5;
        mediump vec3 r = normalize(vec3(d.x + 0.05*w.x, abs(d.y), d.z + 0.05*w.y));
        mediump float mu = max(dot(r, v_sun.xyz), 0.0);
        mediump float m = mu*mu; m *= m; m *= m; m *= m; m *= m; m *= m; m *= m;  // mu^128
        diffuse.rgb += vec3(1.0, 0.88, 0.70)*(m*2.2*v_sun.w);
        diffuse.a = max(diffuse.a, m*v_sun.w);
      }
    #endif
  #else
    #if UM_TEX_DEFINITION
      // definicion: oscurece un poco los pixeles oscuros y aclara los claros
      // (la parte constante ya viene multiplicada en el color del vertice)
      // se usa el canal verde como brillo: 1 MAD escalar + mismas 3 multiplicaciones
      // de siempre (y no cambia el tono de la textura)
      diffuse.rgb = diffuse.rgb*(v_color0.rgb*(1.0 + v_color0.a*diffuse.g)) + v_fog.rgb;
    #else
      diffuse.rgb = diffuse.rgb*v_color0.rgb + v_fog.rgb;
    #endif
    diffuse.a = 1.0;
  #endif

  // (la niebla ya viene mezclada desde el vertice)
  gl_FragColor = diffuse;

  #endif
}
