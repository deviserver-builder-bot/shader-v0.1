vec4 a_color0     : COLOR0;
vec3 a_position   : POSITION;
vec2 a_texcoord0  : TEXCOORD0;
vec2 a_texcoord1  : TEXCOORD1;

vec4 i_data0      : TEXCOORD8;
vec4 i_data1      : TEXCOORD7;
vec4 i_data2      : TEXCOORD6;
vec4 i_data3      : TEXCOORD5;

vec4 v_color0     : COLOR0;
vec4 v_color1     : COLOR1;
vec3 v_fog        : COLOR2;
vec4 v_refl       : COLOR3;
centroid vec2 v_texcoord0  : TEXCOORD0;
vec4 v_wpos       : TEXCOORD1;
vec4 v_sun        : TEXCOORD2;
