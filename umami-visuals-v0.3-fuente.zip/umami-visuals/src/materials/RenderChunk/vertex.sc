$input a_color0, a_position, a_texcoord0, a_texcoord1
#ifdef INSTANCING
  $input i_data0, i_data1, i_data2, i_data3
#endif
$output v_color0, v_texcoord0
#ifdef SEASONS
  $output v_color1
#endif
#ifdef TRANSPARENT
  $output v_refl
  #include <umami/config.h>
  #if UM_WATER_PIXEL_SPEC
    $output v_wpos, v_sun
  #endif
#else
  $output v_fog
#endif

#include <bgfx_shader.sh>
#include <umami/sky.h>

uniform vec4 RenderChunkFogAlpha;
uniform vec4 FogAndDistanceControl;
uniform vec4 ViewPositionAndTime;
uniform vec4 FogColor;
uniform vec4 TimeOfDay;
uniform vec4 CameraPosition;
uniform vec4 MoonPhase;

SAMPLER2D_AUTOREG(s_LightMapTexture);
SAMPLER2D_AUTOREG(s_MatTexture);

// Todo lo de este archivo se calcula por VERTICE (miles por cuadro, no millones):
// por eso puede tener muchos efectos sin bajar los FPS.

void main() {
  #ifdef INSTANCING
    mat4 model = mtxFromCols(i_data0, i_data1, i_data2, i_data3);
  #else
    mat4 model = u_model[0];
  #endif

  vec3 worldPos = mul(model, vec4(a_position, 1.0)).xyz;

  #if !(defined(DEPTH_ONLY_OPAQUE) || defined(DEPTH_ONLY) || defined(INSTANCING))

  vec4 color;
  #ifdef RENDER_AS_BILLBOARDS
    worldPos += vec3(0.5, 0.5, 0.5);
    vec3 toCam = ViewPositionAndTime.xyz - worldPos;
    vec3 vd = normalize(toCam);
    vec3 boardPlane = normalize(vec3(-vd.z, 0.0, vd.x));
    worldPos -= (((vd.zxy*boardPlane.yzx) - (vd.yzx*boardPlane.zxy))*(a_color0.z - 0.5)) +
                (boardPlane*(a_color0.x - 0.5));
    color = vec4(1.0, 1.0, 1.0, 1.0);
  #else
    color = a_color0;
  #endif

  vec3 rel = worldPos - ViewPositionAndTime.xyz;   // camara -> vertice
  float camDis = length(rel);
  vec3 dir = rel/camDis;                            // direccion hacia afuera
  vec3 gp = worldPos + CameraPosition.xyz;          // posicion en el mundo

  // ---- coordenadas de textura y luz (formato del juego) ----
  vec2 uv0 = 2.0*a_texcoord0.xy;
  uv0 = fract(uv0) + ((floor(uv0) - 0.5)/16384.0);
  vec2 uv1 = fract(a_texcoord1.y*vec2(256.0, 4096.0));  // x: antorchas, y: cielo

  highp float t = ViewPositionAndTime.w;
  float rain = umRain(FogAndDistanceControl.xyz);
  vec3 fogCtl = FogAndDistanceControl.xyz;

  // deteccion de dimension: con niebla normal (x >= 0.14) ni siquiera se evalua
  bool underwater = false;
  bool nether = false;
  if (fogCtl.x < 0.14) {
    underwater = umIsUnderwater(FogColor.rgb, fogCtl.xy);
    nether = !underwater && umIsNether(FogColor.rgb, fogCtl.xy);
  }
  bool theEnd = umIsEnd(FogColor.rgb);

  um_time T = umTime(TimeOfDay.x, rain);
  T.moon = umMoonIllum(MoonPhase.x);
  um_light L = umLightColors(T, rain);

  #ifdef SEASONS
    color = vec4(color.www, 1.0);
  #endif

  bool tinted = a_color0.r != a_color0.g || a_color0.r != a_color0.b;
  // sombreado por cara + oclusion ambiental que trae el juego (corregido en bloques tenidos)
  float shade = tinted ? a_color0.g*1.5 : a_color0.g;
  float isTop = shade > 0.8 ? 1.0 : 0.0;

  #if UM_USE_BRIGHTNESS
    float gameBright = texelFetch(s_LightMapTexture, ivec2(0, 0), 0).g;
  #else
    float gameBright = 0.5;
  #endif

  // ---- antorchas: calidas, suaves y (opcional) con un titileo leve ----
  float torch = uv1.x*uv1.x*UM_TORCH_POWER;
  #if UM_TORCH_FLICKER
    // solo donde llega luz de antorcha (casi todo el mundo exterior se lo salta)
    if (torch > 0.002) {
      float ph = dot(floor(gp*0.25), vec3(0.37, 0.11, 0.53));
      torch *= 0.95 + 0.05*umWave(t*2.3 + ph);
    }
  #endif

  vec3 light;
  float sunMask = 0.0;
  if (nether || theEnd) {
    // Nether: la luz toma el color de la niebla de cada bioma (carmesi, distorsionado, almas...)
    vec3 hue = FogColor.rgb/max(max(FogColor.r, max(FogColor.g, FogColor.b)), 0.05);
    vec3 amb = nether ? mix(UM_NETHER_AMBIENT, hue*0.65, 0.45) : UM_END_AMBIENT;
    light = amb*(0.55 + 0.45*gameBright);
    light += UM_TORCH_COLOR*torch;
  } else {
    // sombra suave: el juego no tiene mapa de sombras, usamos la luz del cielo.
    // Debajo de arboles/techos la luz del cielo baja y el sol directo desaparece.
    sunMask = clamp((uv1.y - 0.865)*12.0, 0.0, 1.0);

    #if UM_SIDE_SUN
      // sol alto: ilumina el suelo y deja las paredes en media sombra.
      // sol bajo (amanecer/atardecer): el suelo queda rasante y las paredes se encienden.
      float elev = clamp(abs(T.d)*1.6, 0.0, 1.0);
      float faceSun = isTop > 0.5 ? (0.40 + 0.60*elev) : (0.74 + 0.26*(1.0 - elev));
    #else
      float faceSun = isTop > 0.5 ? 1.0 : UM_SHADOW_SIDE;
    #endif

    // al amanecer/atardecer, el lado del mundo hacia el sol recibe mas luz
    // (condicion igual para todo el cuadro: fuera del amanecer/atardecer no se calcula)
    float dawnSide = 1.0;
    if (T.set > 0.001) {
      float toward = clamp(0.5 + 0.5*dot(rel.xz, T.light.xz)/fogCtl.z, 0.0, 1.0);
      dawnSide = mix(1.0, 0.55 + 0.9*toward, T.set);
    }

    vec3 direct = L.sun*(sunMask*faceSun*dawnSide);
    // luz del cielo: casi lineal como el juego original (sombras suaves, no negras)
    vec3 ambient = L.ambient*(uv1.y*(0.35 + 0.65*uv1.y));

    light = direct + ambient;
    if (rain > 0.01) light = umRainGrey(light, rain);
    // en pleno sol las antorchas se notan menos
    light += UM_TORCH_COLOR*(torch*(1.0 - 0.6*sunMask*T.day));
    #if UM_NIGHT_BOOST
      light += UM_NIGHT_BOOST_COL*((1.0 - T.day)*uv1.y);
    #endif
    // brillo minimo y deslizador de brillo: solo levantan las zonas oscuras
    light += (UM_MIN_LIGHT + vec3_splat(gameBright*0.16))*max(1.0 - light.g, 0.0);
  }

  if (underwater) {
    // causticas baratas: onda triangular en vez de sin()
    vec2 w = abs(fract(vec2(gp.x*0.27 + t*0.25, gp.z*0.31 - t*0.2))*2.0 - 1.0);
    float c = w.x*w.y;
    light *= vec3(0.55, 0.80, 1.00);
    light += vec3(0.10, 0.16, 0.20)*(c*uv1.y);
  }

  // un poco de "brillo" en hojas y plantas tenidas
  if (tinted) {
    light *= 1.04;
  }

  // tope: la luz nunca pasa de x1.15, asi la textura no se "quema"
  light = min(light, vec3_splat(1.15));

  // ---- plantas y hojas que se mueven con el viento ----
  #if UM_PLANT_WAVES && defined(ALPHA_TEST) && !defined(RENDER_AS_BILLBOARDS)
    if (tinted && camDis < UM_WAVE_RANGE) {
      vec3 bPos = fract(a_position);
      bool isLeaves = (bPos.x + bPos.y + bPos.z) < 0.001;
      // vertices de arriba de la textura (la base de la planta queda fija en el suelo)
      float texRows = float(textureSize(s_MatTexture, 0).y)/16.0;
      bool isUpper = fract(uv0.y*texRows) < 0.5;
      float amp = isLeaves ? UM_LEAF_WAVE : (isUpper ? UM_GRASS_WAVE : 0.0);
      amp *= (1.0 + 1.5*rain)*uv1.y*(1.0 - camDis/UM_WAVE_RANGE);
      // funcion de la posicion: vertices compartidos se mueven igual (sin huecos)
      float wp = t*1.4 + gp.x*0.42 + gp.z*0.31;
      worldPos.xz += (amp*umWave(wp))*vec2(1.0, 0.6);
    }
  #endif

  // ---- niebla con el color real del cielo en esa direccion ----
  float relDist = camDis/fogCtl.z + RenderChunkFogAlpha.x;
  float fogA = clamp((relDist - fogCtl.x)/(fogCtl.y - fogCtl.x), 0.0, 1.0);
  fogA = fogA*fogA*(3.0 - 2.0*fogA);
  vec3 fogCol = FogColor.rgb;
  if (underwater) {
    // mirar hacia abajo bajo el agua se ve mas profundo y oscuro
    fogCol *= 1.0 - 0.45*clamp(-dir.y, 0.0, 1.0);
  } else if (!(nether || theEnd)) {
    #if UM_FOG
      // bruma dorada a lo lejos en el atardecer, gris con lluvia
      float hz = max(relDist - 0.25, 0.0);
      fogA = max(fogA, min(hz*hz*(0.39 + 0.62*T.set + 0.8*rain), 0.85));
    #else
      fogA = fogA*fogA;   // sin bruma: solo un desvanecido en el borde del mapa
    #endif
    // el color del cielo solo se calcula si la niebla se va a notar
    if (fogA > 0.004) {
      fogCol = umFogColor(dir, T, rain)*umBiomeTint(FogColor.rgb, T.day, T.set);
    }
  }
  #if UM_LIGHTS_IN_FOG
    // de noche, lo iluminado por antorchas/faroles se ve a traves de la niebla
    fogA *= 1.0 - 0.5*clamp((uv1.x - 0.7)*3.3, 0.0, 1.0)*(1.0 - T.day);
  #endif

  vec4 outColor = vec4(color.rgb*light, color.a);
  vec3 addLight = vec3_splat(0.0);   // luz que se SUMA (gratis en el pixel: va junto con la niebla)

  // ---- superficies mojadas con lluvia ----
  #if UM_WET_RAIN && !defined(TRANSPARENT)
    // condicion igual para todo el cuadro: sin lluvia la GPU se salta este bloque entero
    if (rain > 0.01) {
      float wet = rain*isTop*clamp((uv1.y - 0.9)*10.0, 0.0, 1.0);
      outColor.rgb *= 1.0 - 0.18*wet;            // lo mojado se ve mas oscuro
      float f = 1.0 - abs(dir.y);
      f *= f; f *= f;
      addLight = L.ambient*(0.22*wet*f);         // y refleja un poco el cielo gris
    }
  #endif

  #if !defined(TRANSPARENT) && UM_TEX_DEFINITION
    // curva de definicion  d*(A + B*d)  =  (A*color) * d*(1 + (B/A)*d):
    // A se aplica aqui (gratis por vertice) y el pixel solo hace d*(1 + k*d).
    outColor.rgb *= 1.0 - 0.5*UM_TEX_CONTRAST;
    #if UM_PIXEL_SHINE
      // + los texeles claros al sol brillan un poco mas
      outColor.a = (UM_TEX_CONTRAST + sunMask*T.day*0.35)/(1.0 - 0.5*UM_TEX_CONTRAST);
    #else
      outColor.a = UM_TEX_CONTRAST/(1.0 - 0.5*UM_TEX_CONTRAST);
    #endif
  #endif

  // ---- agua ----
  #ifdef TRANSPARENT
    vec4 refl = vec4(0.0, 0.0, 0.0, 0.0);
    #if UM_WATER_PIXEL_SPEC
      vec4 sunPx = vec4(0.0, 0.0, 0.0, 0.0);
    #endif
    #if !(defined(RENDER_AS_BILLBOARDS) || defined(SEASONS))
    outColor.a = mix(color.a, 1.0, 0.5*clamp(relDist, 0.0, 1.0));
    bool isWater = a_color0.b > 0.3 && a_color0.a < 0.95;
    if (isWater && !underwater) {
      float phase = t*1.8 + gp.x*1.3 + gp.z*0.9;

      #if UM_WATER_WAVES
        if (fract(a_position.y) > 0.01) {
          worldPos.y += UM_WATER_WAVE_HEIGHT*umWave(phase*0.159);
        }
      #endif

      // direccion reflejada (agua plana) + leve ondulacion de la normal
      vec3 r = vec3(dir.x, abs(dir.y), dir.z);
      r.x += 0.06*umWave(phase*0.159 + 0.25);
      r.z += 0.05*umWave(phase*0.127 + gp.x*0.08);

      float f = 1.0 - abs(dir.y);
      float f2 = f*f;
      float fresnel = 0.10 + UM_WATER_FRESNEL*f2*f2;

      um_skycol C = umSkyColors(T, rain);
      r = normalize(r);
      vec3 skyR = umSkyColor(r, C.zen, C.hor*umBiomeTint(FogColor.rgb, T.day, T.set), C.glow, T.light);
      float skyVis = clamp(uv1.y*1.15 - 0.15, 0.0, 1.0);

      refl.rgb = skyR*(fresnel*skyVis);

      #if UM_WATER_PIXEL_SPEC
        // el destello se calcula por pixel en el fragment (nivel Bonito)
        sunPx = vec4(T.light.xyz, sunMask*(1.0 - rain)*(1.0 - fogA)*(0.25 + 0.75*T.day));
      #elif UM_WATER_SPEC
        float mu = max(dot(r, T.light.xyz), 0.0);
        float m = mu*mu; m *= m; m *= m; m *= m; m *= m; m *= m;  // mu^64
        refl.rgb += L.sun*(m*2.5*sunMask);
      #endif

      outColor.rgb *= 0.85 - 0.6*fresnel;
      refl.a = mix(0.55, 1.0, fresnel);
      outColor.a = 0.0;   // el fragment usa max(tex.a*color.a, refl.a)
    }
    #endif
    // niebla ya mezclada aqui: el pixel solo hace color*textura + refl
    refl.rgb = refl.rgb*(1.0 - fogA) + fogCol*fogA;
    v_refl = refl;
    #if UM_WATER_PIXEL_SPEC
      v_wpos = vec4(rel, 0.0);
      v_sun = sunPx;
    #endif
  #endif

  #ifdef DIAGNOSTICO
    // rojo = Nether, morado = End, azul = bajo el agua, amarillo = lluvia, gris = normal
    vec3 dbg = vec3(0.55, 0.55, 0.55);
    if (nether) dbg = vec3(1.0, 0.15, 0.1);
    if (theEnd) dbg = vec3(0.75, 0.2, 1.0);
    if (underwater) dbg = vec3(0.1, 0.35, 1.0);
    dbg = mix(dbg, vec3(1.0, 0.9, 0.1), rain);
    outColor.rgb = dbg;
    fogA = 0.0;
    addLight = vec3_splat(0.0);
  #endif

  v_texcoord0 = uv0;
  // niebla premultiplicada:  mix(c*tex, fog, f) = (c*(1-f))*tex + fog*f
  outColor.rgb *= 1.0 - fogA;
  v_color0 = outColor;
  #ifdef SEASONS
    v_color1 = a_color0;
  #endif
  #ifndef TRANSPARENT
    v_fog = fogCol*fogA + addLight*(1.0 - fogA);
  #endif

  #endif

  gl_Position = mul(u_viewProj, vec4(worldPos, 1.0));
}
