$input v_fog, v_occlusionUVHeight, v_tint, v_texcoord0

#include <bgfx_shader.sh>

uniform vec4 OcclusionHeightOffset;

SAMPLER2D_AUTOREG(s_LightingTexture);
SAMPLER2D_AUTOREG(s_OcclusionTexture);
SAMPLER2D_AUTOREG(s_WeatherTexture);

bool isOccluded(const vec2 occlUV, const float occlHeight, const float occlHeightThreshold) {
  #ifdef NO_OCCLUSION
    return false;
  #else
    bool inBounds = occlUV.x >= 0.0 && occlUV.x <= 1.0 && occlUV.y >= 0.0 && occlUV.y <= 1.0;
    #ifdef FLIP_OCCLUSION
      bool isUnder = occlHeight > occlHeightThreshold;
    #else
      bool isUnder = occlHeight < occlHeightThreshold;
    #endif
    return inBounds && isUnder;
  #endif
}

void main() {
  vec4 diffuse = texture2D(s_WeatherTexture, v_texcoord0);
  vec4 occlData = texture2D(s_OcclusionTexture, v_occlusionUVHeight.xy);

  float occlLuminance = fract(occlData.z*16.0);
  float occlHeightThreshold = ((0.25*occlData.x) + fract(64.0*occlData.y))*1024.0;
  occlHeightThreshold = (occlHeightThreshold + OcclusionHeightOffset.x)/255.0;

  vec2 lightingUV = vec2(0.0, 0.0);
  if (!isOccluded(v_occlusionUVHeight.xy, v_occlusionUVHeight.z, occlHeightThreshold)) {
    float mixAmount = clamp((v_occlusionUVHeight.z - occlHeightThreshold)*25.0, 0.0, 1.0);
    lightingUV = vec2(occlLuminance*(1.0 - mixAmount), 1.0);
  }

  vec3 light = texture2D(s_LightingTexture, lightingUV).rgb;
  diffuse.rgb *= light*v_tint;
  diffuse.rgb = mix(diffuse.rgb, v_fog.rgb, v_fog.a);
  diffuse.a *= lightingUV.y;

  gl_FragColor = diffuse;
}
