$input a_position, a_color0, a_texcoord0, a_indices, a_normal
#ifdef INSTANCING
  $input i_data0, i_data1, i_data2
#endif
$output v_color0, v_fog, v_light, v_texcoord0

#include <bgfx_shader.sh>
#include <MinecraftRenderer.Materials/DynamicUtil.dragonh>
#include <MinecraftRenderer.Materials/TAAUtil.dragonh>

#include <umami/entity.h>

uniform vec4 TileLightColor;
uniform vec4 FogColor;
uniform vec4 FogControl;
uniform vec4 UVAnimation;

uniform mat4 Bones[8];
uniform vec4 ViewPositionAndTime;
uniform vec4 TimeOfDay;
uniform vec4 CameraPosition;
uniform vec4 MoonPhase;

// Mobs y jugadores: luz del sol real segun hacia donde mira cada cara.
void main() {
  mat4 World = u_model[0];
  World = mul(World, Bones[int(a_indices)]);

  vec2 texcoord0 = applyUvAnimation(a_texcoord0, UVAnimation);

  vec3 worldPosition;
  #ifdef INSTANCING
    mat4 model = mtxFromCols(i_data0, i_data1, i_data2, vec4(0.0, 0.0, 0.0, 1.0));
    worldPosition = instMul(model, vec4(a_position, 1.0)).xyz;
  #else
    worldPosition = mul(World, vec4(a_position, 1.0)).xyz;
  #endif

  vec4 position = jitterVertexPosition(worldPosition);

  #if !(defined(DEPTH_ONLY_OPAQUE) || defined(DEPTH_ONLY) || defined(INSTANCING))
    vec3 N = normalize(mul(World, vec4(a_normal.xyz, 0.0)).xyz);
    um_entity E = umEntityShade(N, worldPosition, TileLightColor, FogColor, FogControl.xyz,
                                TimeOfDay.x, MoonPhase.x, CameraPosition.xyz, ViewPositionAndTime.w);
    v_texcoord0 = texcoord0;
    v_color0 = a_color0;
    v_fog = E.fog;
    v_light = vec4(E.light, 1.0);
    
  #else
    v_texcoord0 = texcoord0;
    v_color0 = vec4_splat(0.0);
    v_fog = vec4_splat(0.0);
    v_light = vec4_splat(1.0);
    
  #endif

  gl_Position = position;
}
