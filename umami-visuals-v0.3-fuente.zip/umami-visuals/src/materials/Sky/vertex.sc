#ifndef INSTANCING
  $input a_color0, a_position
  $output v_worldPos, v_zen, v_hor, v_glow, v_light
#endif

#include <bgfx_shader.sh>

#ifndef INSTANCING
  #include <umami/sky.h>

  uniform vec4 FogColor;
  uniform vec4 FogAndDistanceControl;
  uniform vec4 TimeOfDay;
  uniform vec4 MoonPhase;
#endif

void main() {
  #ifndef INSTANCING
    float rain = umRain(FogAndDistanceControl.xyz);
    um_time T = umTime(TimeOfDay.x, rain);
    T.moon = umMoonIllum(MoonPhase.x);
    um_skycol s = umSkyColors(T, rain);
    // cada bioma tiñe un poco su horizonte (desierto calido, pantano verdoso...)
    s.hor *= umBiomeTint(FogColor.rgb, T.day, T.set);

    if (umIsUnderwater(FogColor.rgb, FogAndDistanceControl.xy)) {
      s.zen = FogColor.rgb*0.6;
      s.hor = FogColor.rgb;
      s.glow = vec3_splat(0.0);
    }

    // quad de fondo a pantalla completa
    vec4 pos = vec4(a_position.xzy, 1.0);
    pos.xy = 2.0*clamp(pos.xy, -0.5, 0.5);

    v_worldPos = mul(u_invViewProj, pos).xyz;
    v_zen = s.zen;
    v_hor = s.hor;
    v_glow = s.glow;
    v_light = T.light;

    gl_Position = pos;
  #else
    gl_Position = vec4(0.0, 0.0, 0.0, 0.0);
  #endif
}
