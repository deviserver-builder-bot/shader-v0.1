#ifndef INSTANCING
  $input v_worldPos, v_zen, v_hor, v_glow, v_light
#endif

#include <bgfx_shader.sh>

#ifndef INSTANCING
  #include <umami/sky.h>
#endif

void main() {
  #ifndef INSTANCING
    // normalizar en highp (v_worldPos puede ser grande); el resto en mediump
    mediump vec3 dir = normalize(v_worldPos);
    mediump vec3 col = umSkyColorM(dir, v_zen, v_hor, v_glow, v_light);
    gl_FragColor = vec4(col, 1.0);
  #else
    gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
  #endif
}
