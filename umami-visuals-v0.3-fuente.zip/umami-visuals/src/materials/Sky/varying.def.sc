vec4 a_color0       : COLOR0;
vec3 a_position     : POSITION;
vec2 a_texcoord0    : TEXCOORD0;

vec4 i_data0        : TEXCOORD8;
vec4 i_data1        : TEXCOORD7;
vec4 i_data2        : TEXCOORD6;
vec4 i_data3        : TEXCOORD5;

vec3 v_worldPos     : TEXCOORD0;
vec3 v_zen          : TEXCOORD1;
vec3 v_hor          : TEXCOORD2;
vec3 v_glow         : TEXCOORD3;
vec4 v_light        : TEXCOORD4;
