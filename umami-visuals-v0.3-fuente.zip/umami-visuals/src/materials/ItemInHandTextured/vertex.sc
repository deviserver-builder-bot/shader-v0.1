$input a_position, a_color0, a_texcoord0, a_normal
#ifdef INSTANCING
  $input i_data0, i_data1, i_data2
#endif
$output v_color0, v_fog, v_light, v_texcoord0

#include <bgfx_shader.sh>
#include <MinecraftRenderer.Materials/TAAUtil.dragonh>

#include <umami/entity.h>

uniform vec4 FogControl;
uniform vec4 FogColor;
uniform vec4 TileLightColor;
uniform vec4 ViewPositionAndTime;
uniform vec4 TimeOfDay;
uniform vec4 CameraPosition;
uniform vec4 MoonPhase;


// Objeto en la mano: misma luz que los mobs.
void main() {
  mat4 World = u_model[0];
  vec3 wpos;
  #ifdef INSTANCING
    mat4 model = mtxFromCols(i_data0, i_data1, i_data2, vec4(0.0, 0.0, 0.0, 1.0));
    wpos = instMul(model, vec4(a_position, 1.0)).xyz;
  #else
    wpos = mul(World, vec4(a_position, 1.0)).xyz;
  #endif

  vec4 position = jitterVertexPosition(wpos);

  #if !(defined(DEPTH_ONLY) || defined(INSTANCING))
    vec3 N = normalize(mul(World, vec4(a_normal.xyz, 0.0)).xyz);
    um_entity E = umEntityShade(N, wpos, TileLightColor, FogColor, FogControl.xyz,
                                TimeOfDay.x, MoonPhase.x, CameraPosition.xyz, ViewPositionAndTime.w);
    v_color0 = a_color0;
    v_fog = E.fog;
    v_light = vec4(E.light, 1.0);
  #else
    v_color0 = vec4_splat(0.0);
    v_fog = vec4_splat(0.0);
    v_light = vec4_splat(1.0);
  #endif
  vec2 uv0 = 2.0*a_texcoord0.xy;
  v_texcoord0 = fract(uv0) + ((floor(uv0) - 0.5)/16384.0);
  

  gl_Position = position;
}
