$input a_position, a_texcoord0
$output v_texcoord0, v_tint

#include <bgfx_shader.sh>

#ifndef INSTANCING
  #include <umami/config.h>

  uniform vec4 TimeOfDay;

  mat2 umRot(float t) {
    float s = sin(t);
    float c = cos(t);
    return mtxFromRows(vec2(c, -s), vec2(s, c));
  }
#endif

void main() {
  v_texcoord0 = a_texcoord0;
  #ifndef INSTANCING
    vec3 pos = a_position;
    pos.x = -pos.x;

    vec2 dir = mul(u_model[0], vec4(0.0, 0.0, 0.0, 1.0)).xy;
    float st = 6.283185*TimeOfDay.x + 1.570796;
    bool isSun = dot(vec2(cos(st), sin(st)), dir) > 0.0;

    float dist = 300.0;
    if (isSun) {
      dist = -dist;
      pos.x = -pos.x;
      pos.xz *= 2.2;   // quad mas grande: el halo cabe dentro
    } else {
      pos.xz *= 1.05;
    }
    pos.xz = mul(umRot(0.5*st), pos.xz);

    vec4 wpos = vec4(dist, 70.0*pos.xz, 1.0);
    wpos.xy = mul(umRot(st), -wpos.xy);
    wpos.yz = mul(umRot(UM_SUN_TILT), wpos.yz);

    // tinte: blanco calido al mediodia -> naranja intenso al atardecer
    float d = cos(6.283185*TimeOfDay.x);
    float set = clamp(1.0 - abs(d - 0.04)*4.0, 0.0, 1.0);
    vec3 tint = mix(vec3(1.0, 0.93, 0.80), vec3(1.0, 0.45, 0.12), set);
    v_tint = isSun ? vec4(tint, 1.0) : vec4(0.80, 0.87, 1.0, 0.0);

    gl_Position = mul(u_viewProj, wpos);
  #else
    v_tint = vec4(0.0, 0.0, 0.0, 0.0);
    gl_Position = vec4(0.0, 0.0, 0.0, 0.0);
  #endif
}
