$input v_texcoord0, v_tint

#include <bgfx_shader.sh>

#ifndef INSTANCING
  uniform vec4 SunMoonColor;
  SAMPLER2D_AUTOREG(s_SunMoonTexture);
#endif

void main() {
  #ifndef INSTANCING
    float vis = 1.0 - SunMoonColor.a;
    vis = 1.0 - vis*vis;   // se desvanece con lluvia/nubes

    mediump vec4 color;
    if (v_tint.a > 0.5) {
      // SOL procedural: disco nitido + halo suave (sin leer textura)
      mediump vec2 p = 2.0*v_texcoord0 - 1.0;
      mediump float r2 = dot(p, p);
      mediump float disc = clamp((0.042 - r2)*70.0, 0.0, 1.0);
      mediump float g = max(1.0 - r2, 0.0);
      g *= g; g *= g;
      color.rgb = v_tint.rgb*(disc*1.25 + g*0.42);
      color.a = clamp(disc + g, 0.0, 1.0);
    } else {
      // LUNA: textura de fases, un poco mas brillante y azulada
      color = texture2D(s_SunMoonTexture, v_texcoord0);
      color.rgb *= v_tint.rgb*1.7*color.rgb;
    }
    color.a *= vis;
    gl_FragColor = color;
  #else
    gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0);
  #endif
}
