$input a_color0, a_position
$output v_color0

#include <bgfx_shader.sh>

uniform vec4 StarsColor;
uniform vec4 ViewPositionAndTime;

void main() {
#ifndef INSTANCING
  vec3 pos = a_position;
  vec3 worldPos = mul(u_model[0], vec4(pos, 1.0)).xyz;

  // titileo barato por vertice: cada estrella tiene su propia fase
  float phase = dot(floor(pos*0.35), vec3(12.9898, 78.233, 37.719));
  // titileo con el tiempo real (sigue aunque el ciclo de dia este apagado)
  float tw = 0.72 + 0.28*sin(ViewPositionAndTime.w*2.3 + phase);

  vec4 color = a_color0;
  color.rgb *= StarsColor.rgb*tw*vec3(1.25, 1.30, 1.45);

  v_color0 = color;
  gl_Position = mul(u_viewProj, vec4(worldPos, 1.0));
#else
  v_color0 = vec4(0.0, 0.0, 0.0, 0.0);
  gl_Position = vec4(0.0, 0.0, 0.0, 0.0);
#endif
}
